/**
  ******************************************************************************
  * @file    stm32f4xx_ltdc.h
  * @author  MCD Application Team
  * @version V1.5.1
  * @date    22-May-2015
  * @brief   This file contains all the functions prototypes for the LTDC firmware 
  *          library.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2015 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STM32F4xx_LTDC_H
#define __STM32F4xx_LTDC_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"

/** @addtogroup STM32F4xx_StdPeriph_Driver
  * @{
  */

/** @addtogroup LTDC
  * @{
  */ 

/* Exported types ------------------------------------------------------------*/
 
/** 
  * @brief  LTDC Init structure definition  
  */

typedef struct
{
  uint32_t LTDC_HSPolarity;                 /*!< configures the horizontal��ˮƽ�� synchronization polarity.
		                                             ������ͬ���ź� HSYNC �ļ���
                                                 This parameter can be one value of @ref LTDC_HSPolarity */

  uint32_t LTDC_VSPolarity;                 /*!< configures the vertical(��ֱ) synchronization(ͬ��) polarity(����).
	                                               ���ô�ֱͬ���ź� VSYNC �ļ���
                                                 This parameter can be one value of @ref LTDC_VSPolarity */

  uint32_t LTDC_DEPolarity;                 /*!< configures the data enable polarity. This parameter can
		                                             ��������ʹ���ź� DE �ļ���
                                                 be one of value of @ref LTDC_DEPolarity */

  uint32_t LTDC_PCPolarity;                 /*!< configures the pixel clock polarity. This parameter can
		                                             ��������ʱ���ź� LCD_CLK �ļ���
                                                 be one of value of @ref LTDC_PCPolarity */

  uint32_t LTDC_HorizontalSync;             /*!< configures the number of Horizontal synchronization 
		                                             ������ͬ���ź� HSYNC �Ŀ��� (HSW-1)
                                                 width. This parameter must range from 0x000 to 0xFFF. */

  uint32_t LTDC_VerticalSync;               /*!< configures the number of Vertical synchronization 
		                                             ���ô�ֱͬ���ź� VSYNC �Ŀ���(VSW-1)
                                                 height. This parameter must range from 0x000 to 0x7FF. */

  uint32_t LTDC_AccumulatedHBP;             /*!< configures the accumulated horizontal back porch width.
		                                             ����(HSW+HBP-1)��ֵ
                                                 This parameter must range from LTDC_HorizontalSync to 0xFFF. */

  uint32_t LTDC_AccumulatedVBP;             /*!< configures the accumulated vertical back porch height.
		                                             ����(VSW+VBP-1)��ֵ
                                                 This parameter must range from LTDC_VerticalSync to 0x7FF. */
            
  uint32_t LTDC_AccumulatedActiveW;         /*!< configures the accumulated active width. This parameter
	                                             	����(HSW+HBP+��Ч����-1)��ֵ
                                                 must range from LTDC_AccumulatedHBP to 0xFFF. */

  uint32_t LTDC_AccumulatedActiveH;         /*!< configures the accumulated active height. This parameter 
		                                             ����(VSW+VBP+��Ч�߶�-1)��ֵ
                                                 must range from LTDC_AccumulatedVBP to 0x7FF. */

  uint32_t LTDC_TotalWidth;                 /*!< configures the total width. This parameter 
		                                             ����(HSW+HBP+��Ч����+HFP-1)��ֵ
                                                 must range from LTDC_AccumulatedActiveW to 0xFFF. */

  uint32_t LTDC_TotalHeigh;                 /*!< configures the total height. This parameter 
		                                             ����(VSW+VBP+��Ч�߶�+VFP-1)��ֵ
                                                 must range from LTDC_AccumulatedActiveH to 0x7FF. */
            
  uint32_t LTDC_BackgroundRedValue;         /*!< configures the background red value.
		                                             ���ñ����ĺ�ɫֵ����һ��Ͷ��㶼ȫ͸��ʱ����ɫ
                                                 This parameter must range from 0x00 to 0xFF. */

  uint32_t LTDC_BackgroundGreenValue;       /*!< configures the background green value.
		                                             ���ñ�������ɫֵ
                                                 This parameter must range from 0x00 to 0xFF. */ 

   uint32_t LTDC_BackgroundBlueValue;       /*!< configures the background blue value.
	 	                                             ���ñ�������ɫֵ
                                                 This parameter must range from 0x00 to 0xFF. */
} LTDC_InitTypeDef;

/** 
  * @brief  LTDC Layer���㣩 structure definition  
  */

typedef struct
{
  uint32_t LTDC_HorizontalStart;            /*!< Configures the Window Horizontal Start Position.
	 	                                             ���ô��ڵ�����ʼλ��
                                                 This parameter must range from 0x000 to 0xFFF. */
            
  uint32_t LTDC_HorizontalStop;             /*!< Configures the Window Horizontal Stop Position.
	 	                                             ���ô��ڵ��н���λ��
                                                 This parameter must range from 0x0000 to 0xFFFF. */
  
  uint32_t LTDC_VerticalStart;              /*!< Configures the Window vertical Start Position.
	 	                                             ���ô��ڵĴ�ֱ��ʼλ��
                                                 This parameter must range from 0x000 to 0xFFF. */

  uint32_t LTDC_VerticalStop;               /*!< Configures the Window vaertical Stop Position.
	 	                                             ���ô��ڵĴ�ֱ��λ��
                                                 This parameter must range from 0x0000 to 0xFFFF. */
  
  uint32_t LTDC_PixelFormat;                /*!< Specifies the pixel�����أ� format����ʽ��. This parameter can be 
	 	                                             ���õ�ǰ������ظ�ʽ���������ݴ�֡��������ȡ�����ת��Ϊ�ڲ���ʽ 8888 (ARGB)��
                                                 one of value of @ref LTDC_Pixelformat */

  uint32_t LTDC_ConstantAlpha;              /*!< Specifies the constant�������� alpha used for blending����ϣ�.
	 	                                             ���õ�ǰ���͸���� Alpha ����
                                                 This parameter must range from 0x00 to 0xFF. */

  uint32_t LTDC_DefaultColorBlue;           /*!< Configures the default blue value.
	 	                                             ���õ�ǰ���Ĭ����ɫֵ
                                                 This parameter must range from 0x00 to 0xFF. */

  uint32_t LTDC_DefaultColorGreen;          /*!< Configures the default green value.
	 	                                             ���õ�ǰ���Ĭ����ɫֵ
                                                 This parameter must range from 0x00 to 0xFF. */
            
  uint32_t LTDC_DefaultColorRed;            /*!< Configures the default red value.
	 	                                             ���õ�ǰ���Ĭ�Ϻ�ɫֵ
                                                 This parameter must range from 0x00 to 0xFF. */

  uint32_t LTDC_DefaultColorAlpha;          /*!< Configures the default alpha value.
	 	                                             ���õ�ǰ���Ĭ����ɫ͸��ֵ
                                                 This parameter must range from 0x00 to 0xFF. */

  uint32_t LTDC_BlendingFactor_1;           /*!< Select the blending factor 1. This parameter 
	 	                                             ���û������ BlendingFactor1
                                                 can be one of value of @ref LTDC_BlendingFactor1 */

  uint32_t LTDC_BlendingFactor_2;           /*!< Select the blending factor 2. This parameter 
	 	                                             ���û������ BlendingFactor2
                                                 can be one of value of @ref LTDC_BlendingFactor2 */
            
  uint32_t LTDC_CFBStartAdress;             /*!< Configures the color frame buffer address 
	 	                                            ���õ�ǰ����Դ���ʼλ�� */

  uint32_t LTDC_CFBLineLength;              /*!< Configures the color frame buffer line length.
 	                                             	 ���õ�ǰ��������ݳ��ȣ�ÿ�е���Ч���ص���� * ÿ�����ص��ֽ���+3��
                                                 This parameter must range from 0x0000 to 0x1FFF. */

  uint32_t LTDC_CFBPitch;                   /*!< Configures the color frame buffer pitch in bytes.
	 	                                             ���ô�ĳ�е���ʼ����һ��������ʼ����������һ�����ÿ����Ч���ظ��� * ÿ�����ص��ֽ���
                                                 This parameter must range from 0x0000 to 0x1FFF. */
                                                 
  uint32_t LTDC_CFBLineNumber;              /*!< Specifies the number of line in frame buffer. 
	 	                                             ���õ�ǰ�������
                                                 This parameter must range from 0x000 to 0x7FF. */
} LTDC_Layer_InitTypeDef;

/** 
  * @brief  LTDC Position structure definition  
  */

typedef struct
{
  uint32_t LTDC_POSX;                         /*!<  Current����ǰ�� X Position(λ��) */
  uint32_t LTDC_POSY;                         /*!<  Current Y Position */
} LTDC_PosTypeDef;

typedef struct
{
  uint32_t LTDC_BlueWidth;                        /*!< Blue width ��ɫ ����*/
  uint32_t LTDC_GreenWidth;                       /*!< Green width */
  uint32_t LTDC_RedWidth;                         /*!< Red width */
} LTDC_RGBTypeDef;

typedef struct
{
  uint32_t LTDC_ColorKeyBlue;               /*!< Configures the color key blue value. 
                                                 This parameter must range from 0x00 to 0xFF. */

  uint32_t LTDC_ColorKeyGreen;              /*!< Configures the color key green value. 
                                                 This parameter must range from 0x00 to 0xFF. */
            
  uint32_t LTDC_ColorKeyRed;                /*!< Configures the color key red value. 
                                                 This parameter must range from 0x00 to 0xFF. */
} LTDC_ColorKeying_InitTypeDef;

typedef struct
{
  uint32_t LTDC_CLUTAdress;                 /*!< Configures the CLUT����ɫ���ձ��� address ��ַ.
                                                 This parameter must range from 0x00 to 0xFF. */

  uint32_t LTDC_BlueValue;                  /*!< Configures the blue value. ��ɫֵ
                                                 This parameter must range from 0x00 to 0xFF. */
                                                 
  uint32_t LTDC_GreenValue;                 /*!< Configures the green value. 
                                                 This parameter must range from 0x00 to 0xFF. */

  uint32_t LTDC_RedValue;                   /*!< Configures the red value.
                                                 This parameter must range from 0x00 to 0xFF. */
} LTDC_CLUT_InitTypeDef;

/* Exported constants --------------------------------------------------------*/

/** @defgroup LTDC_Exported_Constants
  * @}
  */
  
/** @defgroup LTDC_SYNC 
  * @{
  */

#define LTDC_HorizontalSYNC               ((uint32_t)0x00000FFF)
#define LTDC_VerticalSYNC                 ((uint32_t)0x000007FF)

#define IS_LTDC_HSYNC(HSYNC) ((HSYNC) <= LTDC_HorizontalSYNC)
#define IS_LTDC_VSYNC(VSYNC) ((VSYNC) <= LTDC_VerticalSYNC)
#define IS_LTDC_AHBP(AHBP)  ((AHBP) <= LTDC_HorizontalSYNC)
#define IS_LTDC_AVBP(AVBP) ((AVBP) <= LTDC_VerticalSYNC)
#define IS_LTDC_AAW(AAW)   ((AAW) <= LTDC_HorizontalSYNC)
#define IS_LTDC_AAH(AAH) ((AAH) <= LTDC_VerticalSYNC)
#define IS_LTDC_TOTALW(TOTALW) ((TOTALW) <= LTDC_HorizontalSYNC)
#define IS_LTDC_TOTALH(TOTALH) ((TOTALH) <= LTDC_VerticalSYNC)

/**
  * @}
  */
  
/** @defgroup LTDC_HSPolarity 
  * @{
  */
#define LTDC_HSPolarity_AL                ((uint32_t)0x00000000)   /*!< Horizontal Synchronization is active low. �͵�ƽ��Ч*/
#define LTDC_HSPolarity_AH                LTDC_GCR_HSPOL           /*!< Horizontal Synchronization is active high. �ߵ�ƽ��Ч*/

#define IS_LTDC_HSPOL(HSPOL) (((HSPOL) == LTDC_HSPolarity_AL) || \
                              ((HSPOL) == LTDC_HSPolarity_AH))  

/**
  * @}
  */
  
/** @defgroup LTDC_VSPolarity 
  * @{
  */
#define LTDC_VSPolarity_AL                ((uint32_t)0x00000000)      /*!< Vertical Synchronization is active low.  �͵�ƽ��Ч*/
#define LTDC_VSPolarity_AH                LTDC_GCR_VSPOL              /*!< Vertical Synchronization is active high. �ߵ�ƽ��Ч*/

#define IS_LTDC_VSPOL(VSPOL) (((VSPOL) == LTDC_VSPolarity_AL) || \
                              ((VSPOL) == LTDC_VSPolarity_AH))  

/**
  * @}
  */
  
/** @defgroup LTDC_DEPolarity 
  * @{
  */
#define LTDC_DEPolarity_AL                ((uint32_t)0x00000000)    /*!< Data Enable, is active low. �͵�ƽ��Ч*/
#define LTDC_DEPolarity_AH                LTDC_GCR_DEPOL            /*!< Data Enable, is active high. �ߵ�ƽ��Ч*/

#define IS_LTDC_DEPOL(DEPOL) (((DEPOL) ==  LTDC_VSPolarity_AL) || \
                              ((DEPOL) ==  LTDC_DEPolarity_AH))

/**
  * @}
  */

/** @defgroup LTDC_PCPolarity 
  * @{
  */
#define LTDC_PCPolarity_IPC               ((uint32_t)0x00000000)    /*!< input pixel clock. ������*/
#define LTDC_PCPolarity_IIPC              LTDC_GCR_PCPOL            /*!< inverted input pixel clock. �½���*/

#define IS_LTDC_PCPOL(PCPOL) (((PCPOL) ==  LTDC_PCPolarity_IPC) || \
                              ((PCPOL) ==  LTDC_PCPolarity_IIPC))

/**
  * @}
  */

/** @defgroup LTDC_Reload 
  * @{
  */
#define LTDC_IMReload                     LTDC_SRCR_IMR    /*!< Immediately Reload. Ӱ�ӼĴ�����������*/
#define LTDC_VBReload                     LTDC_SRCR_VBR    /*!< Vertical Blanking Reload. Ӱ�ӼĴ����ڴ�ֱ��������������*/

#define IS_LTDC_RELOAD(RELOAD) (((RELOAD) == LTDC_IMReload) || \
                                ((RELOAD) == LTDC_VBReload))

/**
  * @}
  */
  
/** @defgroup LTDC_Back_Color
  * @{
  */ 

#define LTDC_Back_Color                   ((uint32_t)0x000000FF)

#define IS_LTDC_BackBlueValue(BBLUE)    ((BBLUE) <= LTDC_Back_Color)
#define IS_LTDC_BackGreenValue(BGREEN)  ((BGREEN) <= LTDC_Back_Color)
#define IS_LTDC_BackRedValue(BRED)      ((BRED) <= LTDC_Back_Color) 

/**
  * @}
  */
      
/** @defgroup LTDC_Position 
  * @{
  */

#define LTDC_POS_CY                       LTDC_CPSR_CYPOS
#define LTDC_POS_CX                       LTDC_CPSR_CXPOS

#define IS_LTDC_GET_POS(POS) (((POS) <= LTDC_POS_CY))


/**
  * @}
  */
      
/** @defgroup LTDC_LIPosition 
  * @{
  */

#define IS_LTDC_LIPOS(LIPOS) ((LIPOS) <= 0x7FF)

/**
  * @}
  */
      
/** @defgroup LTDC_CurrentStatus 
  * @{
  */

#define LTDC_CD_VDES                     LTDC_CDSR_VDES  //��ֱ����ʹ����ʾ״̬
#define LTDC_CD_HDES                     LTDC_CDSR_HDES  //ˮƽ����ʹ����ʾ״̬
#define LTDC_CD_VSYNC                    LTDC_CDSR_VSYNCS//��ֱͬ����ʾ״̬
#define LTDC_CD_HSYNC                    LTDC_CDSR_HSYNCS//ˮƽͬ����ʾ״̬


#define IS_LTDC_GET_CD(CD) (((CD) == LTDC_CD_VDES) || ((CD) == LTDC_CD_HDES) || \
                              ((CD) == LTDC_CD_VSYNC) || ((CD) == LTDC_CD_HSYNC))


/**
  * @}
  */  

/** @defgroup LTDC_Interrupts 
  * @{
  */                           

#define LTDC_IT_LI                      LTDC_IER_LIE   //���ж�
#define LTDC_IT_FU                      LTDC_IER_FUIE  //FIFO �����ж�
#define LTDC_IT_TERR                    LTDC_IER_TERRIE//��������ж�
#define LTDC_IT_RR                      LTDC_IER_RRIE  //�Ĵ��������ж�

#define IS_LTDC_IT(IT) ((((IT) & (uint32_t)0xFFFFFFF0) == 0x00) && ((IT) != 0x00))

/**
  * @}
  */
      
/** @defgroup LTDC_Flag 
  * @{
  */

#define LTDC_FLAG_LI                     LTDC_ISR_LIF    //���жϱ�־
#define LTDC_FLAG_FU                     LTDC_ISR_FUIF   //FIFO �����жϱ�־
#define LTDC_FLAG_TERR                   LTDC_ISR_TERRIF //��������жϱ�־
#define LTDC_FLAG_RR                     LTDC_ISR_RRIF   //�Ĵ��������жϱ�־


#define IS_LTDC_FLAG(FLAG) (((FLAG) == LTDC_FLAG_LI) || ((FLAG) == LTDC_FLAG_FU) || \
                               ((FLAG) == LTDC_FLAG_TERR) || ((FLAG) == LTDC_FLAG_RR))

/**
  * @}
  */
      
/** @defgroup LTDC_Pixelformat 
  * @{
  */
#define LTDC_Pixelformat_ARGB8888                  ((uint32_t)0x00000000)//��ǰ�����ظ�ʽΪARGB8888
#define LTDC_Pixelformat_RGB888                    ((uint32_t)0x00000001)//��ǰ�����ظ�ʽΪRGB888 
#define LTDC_Pixelformat_RGB565                    ((uint32_t)0x00000002)//��ǰ�����ظ�ʽΪRGB565 
#define LTDC_Pixelformat_ARGB1555                  ((uint32_t)0x00000003)
#define LTDC_Pixelformat_ARGB4444                  ((uint32_t)0x00000004)
#define LTDC_Pixelformat_L8                        ((uint32_t)0x00000005)
#define LTDC_Pixelformat_AL44                      ((uint32_t)0x00000006)
#define LTDC_Pixelformat_AL88                      ((uint32_t)0x00000007)

#define IS_LTDC_Pixelformat(Pixelformat) (((Pixelformat) == LTDC_Pixelformat_ARGB8888) || ((Pixelformat) == LTDC_Pixelformat_RGB888)   || \
                        ((Pixelformat) == LTDC_Pixelformat_RGB565)   || ((Pixelformat) == LTDC_Pixelformat_ARGB1555) || \
                        ((Pixelformat) == LTDC_Pixelformat_ARGB4444) || ((Pixelformat) == LTDC_Pixelformat_L8)       || \
                        ((Pixelformat) == LTDC_Pixelformat_AL44)     || ((Pixelformat) == LTDC_Pixelformat_AL88))

/**
  * @}
  */
      
/** @defgroup LTDC_BlendingFactor1 
  * @{
  */

#define LTDC_BlendingFactor1_CA                       ((uint32_t)0x00000400)//���ϵ����ֻ�����㶨�� Alpha ֵ
#define LTDC_BlendingFactor1_PAxCA                    ((uint32_t)0x00000600)//���ϵ���а��������ر����� Alpha ֵ

#define IS_LTDC_BlendingFactor1(BlendingFactor1) (((BlendingFactor1) == LTDC_BlendingFactor1_CA) || ((BlendingFactor1) == LTDC_BlendingFactor1_PAxCA))

/**
  * @}
  */
      
/** @defgroup LTDC_BlendingFactor2
  * @{
  */

#define LTDC_BlendingFactor2_CA                       ((uint32_t)0x00000005)//���ϵ����ֻ�����㶨�� Alpha ֵ
#define LTDC_BlendingFactor2_PAxCA                    ((uint32_t)0x00000007)//���ϵ���а��������ر����� Alpha ֵ

#define IS_LTDC_BlendingFactor2(BlendingFactor2) (((BlendingFactor2) == LTDC_BlendingFactor2_CA) || ((BlendingFactor2) == LTDC_BlendingFactor2_PAxCA))


/**
  * @}
  */
      
     
/** @defgroup LTDC_LAYER_Config
  * @{
  */

#define LTDC_STOPPosition                 ((uint32_t)0x0000FFFF)
#define LTDC_STARTPosition                ((uint32_t)0x00000FFF)

#define LTDC_DefaultColorConfig           ((uint32_t)0x000000FF)
#define LTDC_ColorFrameBuffer             ((uint32_t)0x00001FFF)
#define LTDC_LineNumber                   ((uint32_t)0x000007FF)

#define IS_LTDC_HCONFIGST(HCONFIGST) ((HCONFIGST) <= LTDC_STARTPosition)
#define IS_LTDC_HCONFIGSP(HCONFIGSP) ((HCONFIGSP) <= LTDC_STOPPosition)
#define IS_LTDC_VCONFIGST(VCONFIGST)  ((VCONFIGST) <= LTDC_STARTPosition)
#define IS_LTDC_VCONFIGSP(VCONFIGSP) ((VCONFIGSP) <= LTDC_STOPPosition)

#define IS_LTDC_DEFAULTCOLOR(DEFAULTCOLOR) ((DEFAULTCOLOR) <= LTDC_DefaultColorConfig)

#define IS_LTDC_CFBP(CFBP) ((CFBP) <= LTDC_ColorFrameBuffer)
#define IS_LTDC_CFBLL(CFBLL) ((CFBLL) <= LTDC_ColorFrameBuffer)

#define IS_LTDC_CFBLNBR(CFBLNBR) ((CFBLNBR) <= LTDC_LineNumber)



/**
  * @}
  */
          
/** @defgroup LTDC_colorkeying_Config
  * @{
  */

#define LTDC_colorkeyingConfig            ((uint32_t)0x000000FF)

#define IS_LTDC_CKEYING(CKEYING) ((CKEYING) <= LTDC_colorkeyingConfig)


/**
  * @}
  */
          
/** @defgroup LTDC_CLUT_Config
  * @{
  */

#define LTDC_CLUTWR                       ((uint32_t)0x000000FF)

#define IS_LTDC_CLUTWR(CLUTWR)  ((CLUTWR) <= LTDC_CLUTWR)

/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */

/*  Function used to set the LTDC configuration to the default reset state *****/
void LTDC_DeInit(void);     //��λLTDC

/* Initialization and Configuration functions *********************************/
void LTDC_Init(LTDC_InitTypeDef* LTDC_InitStruct);             //��ʼ��LTDC
void LTDC_StructInit(LTDC_InitTypeDef* LTDC_InitStruct);       //���LTDC_InitStructΪĬ��ֵ
void LTDC_Cmd(FunctionalState NewState);                       //ʹ��or��ֹLTDC������
void LTDC_DitherCmd(FunctionalState NewState);                 //�����͹رն�����
LTDC_RGBTypeDef LTDC_GetRGBWidth(void);                        //�õ�����RGB�Ŀ���
void LTDC_RGBStructInit(LTDC_RGBTypeDef* LTDC_RGB_InitStruct); //���LTDC_RGBStructΪĬ��ֵ
void LTDC_LIPConfig(uint32_t LTDC_LIPositionConfig);           //�������ж�λ��
void LTDC_ReloadConfig(uint32_t LTDC_Reload);                  //����Ӱ������
/*��ʼ��LTDC��*/
void LTDC_LayerInit(LTDC_Layer_TypeDef* LTDC_Layerx, LTDC_Layer_InitTypeDef* LTDC_Layer_InitStruct);
void LTDC_LayerStructInit(LTDC_Layer_InitTypeDef * LTDC_Layer_InitStruct);     // ���LTDC_Layer_InitStructΪĬ��ֵ
void LTDC_LayerCmd(LTDC_Layer_TypeDef* LTDC_Layerx, FunctionalState NewState); //ʹ��or��ָֹ���� LTDC_Layer
LTDC_PosTypeDef LTDC_GetPosStatus(void);                                       //��ȡ��ǰλ��
void LTDC_PosStructInit(LTDC_PosTypeDef* LTDC_Pos_InitStruct);                 //���LTDC_Pos_InitStructΪĬ��ֵ
FlagStatus LTDC_GetCDStatus(uint32_t LTDC_CD);                                 //���ָ���ı�־λ�Ƿ���λ
/*ɫ������*/
void LTDC_ColorKeyingConfig(LTDC_Layer_TypeDef* LTDC_Layerx, LTDC_ColorKeying_InitTypeDef* LTDC_colorkeying_InitStruct, FunctionalState NewState);
/*��� LTDC_colorkeying_InitStructΪĬ��ֵ*/
void LTDC_ColorKeyingStructInit(LTDC_ColorKeying_InitTypeDef* LTDC_colorkeying_InitStruct);
void LTDC_CLUTCmd(LTDC_Layer_TypeDef* LTDC_Layerx, FunctionalState NewState);//��ɫ��ʹ��or��ֹ
/*��ɫ����ʼ��*/
void LTDC_CLUTInit(LTDC_Layer_TypeDef* LTDC_Layerx, LTDC_CLUT_InitTypeDef* LTDC_CLUT_InitStruct);
void LTDC_CLUTStructInit(LTDC_CLUT_InitTypeDef* LTDC_CLUT_InitStruct); //���LTDC_CLUT_InitStruct
/*��������ͼ��λ�á������¶�λ���ڵ�λ�ã����ǲ��ܸı䴰�ڵĴ�С*/
void LTDC_LayerPosition(LTDC_Layer_TypeDef* LTDC_Layerx, uint16_t OffsetX, uint16_t OffsetY);
void LTDC_LayerAlpha(LTDC_Layer_TypeDef* LTDC_Layerx, uint8_t ConstantAlpha);//��������alpha����
void LTDC_LayerAddress(LTDC_Layer_TypeDef* LTDC_Layerx, uint32_t Address);   //��������ǰ����Դ���ʼλ��
/*��������ǰ��Ĵ�С*/
void LTDC_LayerSize(LTDC_Layer_TypeDef* LTDC_Layerx, uint32_t Width, uint32_t Height);
/*�������õ�ǰ������ظ�ʽ*/
void LTDC_LayerPixelFormat(LTDC_Layer_TypeDef* LTDC_Layerx, uint32_t PixelFormat);

/* Interrupts and flags management functions **********************************/
void LTDC_ITConfig(uint32_t LTDC_IT, FunctionalState NewState);//�ж�ʹ��or��ֹ
FlagStatus LTDC_GetFlagStatus(uint32_t LTDC_FLAG);             //���ָ���жϱ�־λ�Ƿ�ֵλ
void LTDC_ClearFlag(uint32_t LTDC_FLAG);                       //�����־λ
ITStatus LTDC_GetITStatus(uint32_t LTDC_IT);                   //����Ƿ���ָ���жϣ����ڽ����жϺ��ж���������������ж�
void LTDC_ClearITPendingBit(uint32_t LTDC_IT);                 //����жϹ���λ������ı� NVIC,�����жϳ����������־λ

#ifdef __cplusplus
}
#endif

#endif /* __STM32F4xx_LTDC_H */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
