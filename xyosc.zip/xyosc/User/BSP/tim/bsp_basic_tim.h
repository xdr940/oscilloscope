#ifndef __BASIC_TIM_H
#define	__BASIC_TIM_H

#include "stm32f4xx.h"

/*-----------------us ��------------------------------------*/
#define BASIC_TIM           		TIM6
#define BASIC_TIM_CLK       		RCC_APB1Periph_TIM6
#define BASIC_TIM_IRQn					TIM6_DAC_IRQn
#define BASIC_TIM_IRQHandler    TIM6_DAC_IRQHandler

#define BASIC_TIM_Period 				(10000-1)//10000��/�ж� range from 0~65535,10ms
#define BASIC_TIM_Prescaler					90-1// 180M/2  /180 = 1000000 times/S-->1us/��

/*--------------------S��-----------------------------*/

#define SEC_TIM           		TIM7
#define SEC_TIM_CLK       		RCC_APB1Periph_TIM7
#define SEC_TIM_IRQn					TIM7_DAC_IRQn
#define SEC_TIM_IRQHandler    TIM7_DAC_IRQHandler

#define SEC_TIM_Period 				(10000-1)//10000��/�ж� range from 0~65535,10ms
#define SEC_TIM_Prescaler					9000-1// 180M/18000 = 10000 times/S-->100us/��





//has the scale of 5second(50000*100us = 5s)



void TIMx_Configuration(void);
int us_between(int t1,int t2);
int BASIC_TIM_getValue();

int SEC_TIM_getValue();
int SEC_us_between(int s1,int s2);

#endif /* __BASIC_TIM_H */

