/**
  ******************************************************************************
  * @file    bsp_basic_tim.c
  * @author  STMicroelectronics
  * @version V1.0
  * @date    2015-xx-xx
  * @brief   ������ʱ����ʱ����
  ******************************************************************************
  * @attention
  *
  * ʵ��ƽ̨:����  STM32 F429 ������  
  * ��̳    :http://www.firebbs.cn
  * �Ա�    :http://firestm32.taobao.com
  *
  ******************************************************************************
  */
  
#include "./tim/bsp_basic_tim.h"

 /**
  * @brief  ������ʱ�� TIMx,x[6,7]�ж����ȼ�����
  * @param  ��
  * @retval ��
  */
static void TIM_Mode_Config(void)
{
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;


  RCC_APB1PeriphClockCmd(BASIC_TIM_CLK, ENABLE);

  TIM_TimeBaseStructure.TIM_Period = BASIC_TIM_Period;       
	

  TIM_TimeBaseStructure.TIM_Prescaler = BASIC_TIM_Prescaler;	

	TIM_TimeBaseInit(BASIC_TIM, &TIM_TimeBaseStructure);
	
	
	
	TIM_Cmd(BASIC_TIM, ENABLE);	
	
	
	
}
static void SEC_TIM_Mode_Config(void)
{
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;


  RCC_APB1PeriphClockCmd(SEC_TIM_CLK, ENABLE);

  TIM_TimeBaseStructure.TIM_Period =SEC_TIM_Period;       
	

  TIM_TimeBaseStructure.TIM_Prescaler =SEC_TIM_Prescaler;	

	TIM_TimeBaseInit(SEC_TIM, &TIM_TimeBaseStructure);
	
	
	
	TIM_Cmd(SEC_TIM, ENABLE);	
	
	
	
}



  
void TIMx_Configuration(void)
{
	
  
  TIM_Mode_Config();
	SEC_TIM_Mode_Config();
}


int BASIC_TIM_getValue(){

	return BASIC_TIM->CNT;//range from 0~10000-1
}

int us_between(int t1,int t2){
	if(t2>t1){
		return (t2-t1);
		
	}else{
		return (BASIC_TIM_Period-t1+t2);
	}

}


int ms_between(int t1,int t2){
	return 1;
		if(t2>t1){
		return (t2-t1)/10;
		
	}else{
		return (BASIC_TIM_Period-t1+t2)/10;
	}
}


int SEC_TIM_getValue(){

	return SEC_TIM->CNT;
}

int SEC_us_between(int s1,int s2){

		if(s2>s1){
		return (s2-s1)*100;
		
	}else{
		return 100*(SEC_TIM_Period-s1+s2);
	}

}




/*********************************************END OF FILE**********************/
