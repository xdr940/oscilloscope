/**
 *
 * ʵ��ƽ̨:���� STM32 F429 ������
 ******************************************************************************
 */
#include "main.h"





/*********************************************************************
 *
 * mainTask code
 *
 ***********************************************************************/
int main( void )
{	
/**************************       stm32       ********************************************/
	usart_Init( 115200 );
	/*CRC��emWinû�й�ϵ��ֻ������Ϊ�˿�ı��������ģ�����STemWin�Ŀ�ֻ������ST��оƬ���棬���оƬ���޷�ʹ�õġ� */
	RCC_AHB1PeriphClockCmd( RCC_AHB1Periph_CRC, ENABLE );
	/*LCD��ʼ��*/
		bsp_LCD_Init(); /* SDRAM�ڸú����б���ʼ�� */
		printf( "bsp_LCD_Init OK\n" );
	LCD_Layer1Init();
	led_Init(LEDR);
		LCD_Layer2Init();
	printf( "LCD_LayerInit OK \n" );
		/*GUI ��ʼ��*/
	GUI_Init();
		printf( "GUI_Init OK\n" );
	GUI_SetColor( GUI_BLUE );
	GUI_SetBkColor( GUI_BLACK );
	GUI_Clear();


	/*������ʼ��*/
	I2C_Touch_Init();
	I2C_GTP_IRQEnable(); /* �򿪴������ж� */
	/*���ڳ�ʼ��*/
	/*systick��ʼ��*/
	SysTick_Init();
		/**/
		
		/* adc */
	Rheostat_Init();
	printf( "Rheostat_Init ok\n" );
		TIMx_Configuration();
		printf( "TIMx_Configuration OK\n" );
		
/**************************       end       ********************************************/
	
	
	
	
	WM_HWIN hDlg, hGraph = 0;
	WM_SetDesktopColor( GUI_BLACK );
#if GUI_SUPPORT_MEMDEV /* ?? 1 memory device available */
	WM_SetCreateFlags( WM_CF_MEMDEV );
#endif
	hDlg = GUI_CreateDialogBox( _aDialogCreate, GUI_COUNTOF( _aDialogCreate ), &_cbCallback, 0, 10, 0 );

initStructs(&framedata,&curveStruct,Wsize);

	while ( 1 )
	{	
#ifdef WIN32
		//GUI_Delay( 1 );
#endif
		if ( !_Stop )
		{
			if ( !hGraph ) 

			{
				hGraph = WM_GetDialogItem( hDlg, GUI_ID_GRAPH0 ); 
			}
			_updateValues( hGraph ,&framedata,&curveStruct); /* ���²���ֵ */
			_updateFrameData(&framedata,&curveStruct);			/*��ÿ֡ͼ������ݴ����������뵽�����ṹ����*/
			showData( hDlg, &framedata);			/*��ʾƵĻ���Ͻǵ���ֵ����*/
		}
		GUI_Exec();
	}
}



 void _updateValues(WM_HWIN hGraph,FrameData*framedata,CurveStruct*curveStruct) {    /* WM_HWIN ???int? */

											   /* addValue? */
	int i = 0;


	/*sampling */
	
	 
	 switch(Model){
		
		 case TESTMODEL:
			  t1=BASIC_TIM_getValue();
				for (i = 0; i < Wsize; i++) {
				curveStruct->data_t[i] = 5 * cos(i / N)*(float)rand()/100 ;
				}
				t2=BASIC_TIM_getValue();
				
		 break;
				
	
				
		 case SAMPMODEL:
			 t1=BASIC_TIM_getValue();
				for (i = 0; i < Wsize; i++) {
			
				curveStruct->data_t[i] = ((uint16_t)ADC_ConvertedValue[i%2]); 
				SysTick_Delay_us(delayus);
				}
				t2=BASIC_TIM_getValue();
		 break;
	 
	 
	 }//switch
	
	 
	 
	 framedata->sampT = us_between(t1,t2);
	 if(Model!=TESTMODEL){
		  //�õ�����ʱ�䣨�������ߣ�
			for(i=0;i<Wsize;i++){
			curveStruct->data_t[i] =(float)(curveStruct->data_t[i] *9.999/65536-5);//set range from -5.00~5.00
		
			}
		
			/*-----------filter process-------*/
			for(i=0;i<8;i++){
				buf[i]=	curveStruct->data_t[i];
			}
			for(i=0;i<Wsize;i++){
					curveStruct->data_t[i]=Filter(	curveStruct->data_t[i],buf,8);
				
			}
	
	
		/*-----------------------------------*/
	 
	 
	 }
	 
		
	
	/*---------------------------processing---------------------------------*/
		for (i = 0; i < Wsize; i++) {           /* ???? */
											/*timeBase change*/
		
			curveStruct->pix_t[i] = (rel2pix *	curveStruct->data_t[i]) + center;; //for timeBase change
		
		if (i * (timeBaseFactor) < Wsize) {
				curveStruct->dataTemp[i* (timeBaseFactor)] = curveStruct->pix_t[i];

		}
	

		GRAPH_DATA_YT_AddValue(_ahData[TDOMAIN2], 	curveStruct->data_t2[i]);
		/*FFT*/
		
		if (_fft)
		{
			GRAPH_DATA_YT_AddValue(_ahData[FDOMAIN], 	curveStruct->data_f[i]);
		}
		
		

	}

	if (_fft)//??fft,??????
	{
		FFT(	curveStruct->data_t, curveStruct->dst, Wsize);

		abs_Complex(curveStruct->dst, 	curveStruct->data_f);//data_f??????
		
		
	}
	/**/
	if (timeBaseFactor!=1) {
		interpolation(	curveStruct->dataTemp, timeBaseFactor,Wsize);
	
	}
	for (i = 0; i < Wsize; i++) {
		curveStruct->	data_t2[i] = 	curveStruct->dataTemp[i];
		
	}
	


}




static void _updateFrameData(FrameData *framedata, CurveStruct*curveStruct) {
	
	int subOfMax;//subscript

	int i = 0;

	framedata->rms = RMS(curveStruct->data_t);

	/*curveStruct->data_t*/
	for (i = 0; i < Wsize; i++) {
		if (curveStruct->data_t[i] < framedata->minTD) {//???????
			framedata->minTD =curveStruct->data_t[i];
		}
		if (curveStruct->data_t[i] > framedata->maxTD) {//???????
			framedata->maxTD = curveStruct->data_t[i];
		}
		framedata->sumTD += curveStruct->data_t[i];
	
	}
	
	framedata->mean = framedata->sumTD / Wsize;//caculate MEAN
	framedata->Vpp = framedata->maxTD - framedata->minTD;//
	/*curveStruct->data_f*/

	if (_fft) {//

		int temp = 0;
	
		for (i =1; i < Wsize / 2; i++) {//256
			if (curveStruct->data_f[i] > temp) {//
				temp = curveStruct->data_f[i];
				subOfMax = i;
			}

			framedata->FPP[i / 51] += curveStruct->data_f[i]*curveStruct->data_f[i];
			
		}
		
		/*---------------------frequency caculate through FFT ---------------------------*/
	framedata->freq = 0.512*(1000*subOfMax)/((512.0/1000)*framedata->sampT);
		
	/*-------------------------------0.512 ����ϵ��----------------------------------------------*/
		
		for (i = 0; i < 10; i++) {
			framedata->sumFD += framedata->FPP[i];
		}
		for (i = 0; i < 10; i++) {
			framedata->FPP[i] /= (framedata->sumFD / 100);
		}

	}
/**********--------*********/
	
	/*timeBase caculate */
	framedata->timeBase =1835/ timeBaseFactor;//1835 ���ݼ�ʱ�������1835
	framedata->vDiv = (float)1.25 / vDivFac;
	framedata->Sas = (float)Wsize/framedata->sampT;
		

	framedata->ScreenRefTime =(float) SEC_us_between(t3,SEC_TIM_getValue())/1000000;
	
	t3 = SEC_TIM_getValue();
	LEDR_T;
}


static void showData(WM_HWIN hDlg, FrameData* framedata) {



	int i;
	char databuf[20];
	

	sprintf(databuf, "%.2f V", framedata->minTD);
	TEXT_SetText(WM_GetDialogItem(hDlg, ID_TEXT_0), databuf);

	sprintf(databuf, "%.2f V", framedata->maxTD);
	TEXT_SetText(WM_GetDialogItem(hDlg, ID_TEXT_1), databuf);

	sprintf(databuf, "%.2f V", framedata->Vpp);
	TEXT_SetText(WM_GetDialogItem(hDlg, ID_TEXT_2), databuf);

	sprintf(databuf, "%.2f V", framedata->mean);
	TEXT_SetText(WM_GetDialogItem(hDlg, ID_TEXT_3), databuf);

	sprintf(databuf, "%.2f K", framedata->Sas);
		
	TEXT_SetText(WM_GetDialogItem(hDlg, ID_TEXT_5), databuf);//5 sas
	
	
	sprintf(databuf, "%.2f V", framedata->rms);//vdiv
	TEXT_SetText(WM_GetDialogItem(hDlg, ID_TEXT_6), databuf);


	

	if(Model == SAMPMODEL){
			sprintf(databuf, "%.2f us", framedata->timeBase);
		
	}else{
			sprintf(databuf, "- ");
	}
	TEXT_SetText(WM_GetDialogItem(hDlg, ID_TEXT_7), databuf);//5 sas
	
	sprintf(databuf, "%.2f ", framedata->ScreenRefTime);
		
	TEXT_SetText(WM_GetDialogItem(hDlg, ID_TEXT_0+8), databuf);//5 sas


		
	if (_fft) {
		
			sprintf(databuf, "%.1fKHz", framedata->freq);//��Ƶģʽ
		
		
			//sprintf(databuf, "- KHz");//��Ƶģʽ
		
		
		TEXT_SetText(WM_GetDialogItem(hDlg, ID_TEXT_4), databuf);
	
		for (i = 0; i < 10; i++) {

			sprintf(databuf, "%.2f %%", framedata->FPP[i]);
		
			TEXT_SetText(WM_GetDialogItem(hDlg, ID_TEXT_10 + i), databuf);

		}
	}
	if(Model==TESTMODEL){
		TEXT_SetText(WM_GetDialogItem(hDlg, ID_TEXT_0+9), "Noise Test");//5 sas
	}
	
	if(Model==SAMPMODEL){
		TEXT_SetText(WM_GetDialogItem(hDlg, ID_TEXT_0+9), "SAMPLING");//5 sas
	}
	

	
	
	
	framedata->sumFD = 0;
	framedata->sumTD = 0;
	
	



}






static void _cbCallback(WM_MESSAGE * pMsg)
{
	int		i, NCode, Id;                                                            /* id :????????id  1???,3?checkbox??? */
	
	WM_HWIN		hDlg, hItem, _hMEdit;                                                                    /* hItem ????? */

	hDlg = pMsg->hWin;
	switch (pMsg->MsgId)                                                                          /* ?? ?? ?? ,?????switch???? */
	{
	case WM_INIT_DIALOG: {                                 /* ??????,????????????????? */
		hItem = WM_GetDialogItem(hDlg, GUI_ID_GRAPH0);
		/* Add graphs */
		for (i = 0; i < GUI_COUNTOF(_aColor); i++)
		{
			                                           /* ??????? */
			_ahData[i] = GRAPH_DATA_YT_Create(_aColor[i], PointDisNum, 0, 0);        /* ??????600???? */
			GRAPH_AttachData(hItem, _ahData[i]);                                          /* ????? ??? ????? */
		}
		
	
		/*set editeare*/
		_hMEdit = WM_GetDialogItem(hDlg, GUI_ID_MULTIEDIT0);
		
		
		
		MULTIEDIT_SetBkColor(_hMEdit, MULTIEDIT_CI_EDIT, GUI_BLACK);
		/*Tex*/
		 TEXT_SetDefaultFont(GUI_FONT_13H_ASCII);
		 TEXT_SetDefaultTextColor(GUI_WHITE);
		
		 int step = 20;
		 int init = 10;
		

		 for (i = 0; i < 10; i++) {//????

			 TEXT_SetTextColor(WM_GetDialogItem(hDlg, GUI_ID_TEXT0+i), GUI_WHITE);
			 TEXT_SetFont(WM_GetDialogItem(hDlg, GUI_ID_TEXT0+i), GUI_FONT_13H_ASCII);
		 }
		
		 for (i = 0; i < 10; i++) {//????
			 TEXT_CreateEx(80, 5+i*step, 60, 20, _hMEdit, WM_CF_SHOW, TEXT_CF_HCENTER, ID_TEXT_0+i, "-");//miTD 0~ sas 5
		 }
		

		 
		 /*freq bottom*/
		 
		 
		 TEXT_SetDefaultTextColor(GUI_YELLOW);
		 TEXT_SetDefaultFont(GUI_FONT_8_ASCII);
		  step = 50;
		  init = 30;
		 for (i = 0; i < 10; i++) {//����Ƶ���ʷ���
			 TEXT_CreateEx(init+i*step, 370, 60, 20, hItem, WM_CF_SHOW, TEXT_CF_HCENTER, ID_TEXT_10+i, "-");
		 }
		 
		
		
		/* Set graph attributes */
		GRAPH_SetGridDistY(hItem, 25);
		GRAPH_SetGridVis(hItem, 1);                                                           /* ???? */
		GRAPH_SetGridFixedX(hItem, 1);                                                     /* X????? */
		GRAPH_SetUserDraw(hItem, _UserDraw);
		GRAPH_SetBorder(hItem, 35, 0, 0, 20);
		
		/* Create and add vertical scale */ //????
		_hScaleV = GRAPH_SCALE_Create(35, GUI_TA_RIGHT, GRAPH_SCALE_CF_VERTICAL, NbrScaleNbr);//100???????
		GRAPH_SCALE_SetTextColor(_hScaleV, GUI_BLUE);
		GRAPH_AttachScale(hItem, _hScaleV);
		GRAPH_SCALE_SetOff(_hScaleV, center);//?????
		GRAPH_SCALE_SetFactor(_hScaleV, hScaleFac);//????? .05*100 = 5V
		GRAPH_SCALE_SetNumDecs(_hScaleV, 2);
		/* Create and add horizontal scale */
		
		_hScaleH = GRAPH_SCALE_Create(390, GUI_TA_HCENTER, GRAPH_SCALE_CF_HORIZONTAL, 50);
		GRAPH_SCALE_SetTextColor(_hScaleH, GUI_BLUE);
		GRAPH_AttachScale(hItem, _hScaleH);
		GRAPH_SCALE_SetFactor(_hScaleH,100);//?????




	
		/* Init slider widgets */
		hItem = WM_GetDialogItem(hDlg, GUI_ID_SLIDER0);       /* time */
		SLIDER_SetRange(hItem, 0, 5);
		SLIDER_SetValue(hItem, 3);
		SLIDER_SetNumTicks(hItem, 1);                         /* ?? */
		hItem = WM_GetDialogItem(hDlg, GUI_ID_SLIDER1);
		SLIDER_SetRange(hItem, 0, 20);
		SLIDER_SetValue(hItem, 10);
		SLIDER_SetNumTicks(hItem, 1);                         /* ?? */
		break;
	}
	case WM_NOTIFY_PARENT: {        /* ?????,???????????,??????????????? */
		Id = WM_GetId(pMsg->hWinSrc); /* Id of widget */ /* ???????id */
		NCode = pMsg->Data.v; /* Notification code */         /* ????? */
		switch (NCode) {

		case WM_NOTIFICATION_CLICKED: {                        /* ??????? */
			switch (Id) {

			case GUI_ID_BUTTON0:                            /* ??????ID? ?GUI_ID_BUTTON0 ?(??fullScreenMode) */
				_ToggleFullScreenMode(hDlg);
				break;
			case GUI_ID_BUTTON3: {                           /* stop */
				_Stop = !_Stop;
				break;
			}
			case GUI_ID_BUTTON1: {                            /* FFT */

				if (_fft == 0)
				{
					_fft = 1;
					GRAPH_DATA_YT_MirrorX(_ahData[FDOMAIN], 1);
				}
				else {
					_fft = 0;
					/* ????? */
					GRAPH_DATA_YT_Clear(_ahData[FDOMAIN]);
				}
				break;
			}
			
			case GUI_ID_BUTTON4:    /* PrtSc */

				break;
			case GUI_ID_BUTTON5: {    /* up */
				center += 20;
				GRAPH_SCALE_SetOff(_hScaleV, center);
				break;
			}
			case GUI_ID_BUTTON6: {   /* down */
				
				center -= 20;
				GRAPH_SCALE_SetOff(_hScaleV, center);
				break;
			}
			case GUI_ID_BUTTON7: {    /* volts/div_up */
				
					hScaleFac /= 2;
		
					GRAPH_SCALE_SetFactor(_hScaleV, hScaleFac);
					GRAPH_SCALE_SetTickDist(_hScaleV, NbrScaleNbr);
					rel2pix *=2;
					vDivFac*=2;
				break;
			}
			case GUI_ID_BUTTON8: {    /* volts/div_down */
				
				
				
					hScaleFac *= 2;
					//NbrScaleNbr /=2;

					GRAPH_SCALE_SetTickDist(_hScaleV, NbrScaleNbr);
					GRAPH_SCALE_SetFactor(_hScaleV, hScaleFac );
					rel2pix /=2;
					vDivFac /= 2;
				
				break;
			}
			case GUI_ID_BUTTON9: {    /* freq/div_dow for test */
				if (Model=TESTMODEL) {//test
					N /= 1.2;
				}
					
				
				
				
				GRAPH_DATA_YT_Clear(_ahData[TDOMAIN2]);
				break;
			}
			case GUI_ID_BUTTON10: {   /* freq/div_up for test */
				if (Model==TESTMODEL) {
					N *= 1.2;
					GRAPH_DATA_YT_Clear(_ahData[TDOMAIN2]);
				}
			
				break;
			}
			case GUI_ID_BUTTON11: {   /* ����*/
				
					if (timeBaseFactor < MAXFACTOR) {
							timeBaseFactor *= 2;
						}
					if(Model!=TESTMODEL){
					
						if(delayus>1){
								delayus--;//inprove sampling freq
						}
						GRAPH_DATA_YT_Clear(_ahData[TDOMAIN]);//??
						
				}
				
				 
				break;
			}
			case GUI_ID_BUTTON12: {   /* ���� */
					if (timeBaseFactor >= 2){
						timeBaseFactor /= 2;
					}
					if(Model!=TESTMODEL){
					
						if (timeBaseFactor == 1) {
							delayus++;
						}
				}
				break;
			}
			case GUI_ID_BUTTON14: {
				Model=(Model+1)%2;// 2 models
			

			}
			default: {
				WM_DefaultProc(pMsg);
			}


			}
		}//button case over WM_NOTIFICATION_CLICKED


		}
	}
	default: {
		WM_DefaultProc(pMsg);
	}

			 /* ( pMsg->MsgId ) */

	}
}





/*********************************************************************
 *
 * emWin code
 *
 ***********************************************************************/
static void _UserDraw( WM_HWIN hWin, int Stage )
{
	if ( Stage == GRAPH_DRAW_LAST )
	{
		char		acText[] = "Volts";
		GUI_RECT	Rect, RectInvalid;
		int		FontSizeY;
		GUI_SetFont( &GUI_Font13_ASCII );
		FontSizeY = GUI_GetFontSizeY();
		WM_GetInsideRect( &Rect );
		WM_GetInvalidRect( hWin, &RectInvalid );
		Rect.x1 = Rect.x0 + FontSizeY;
		GUI_SetColor( GUI_YELLOW );
		GUI_DispStringInRectEx( acText, &Rect, GUI_TA_HCENTER, strlen( acText ), GUI_ROTATE_CCW );
	}
}






/*********************************************************************
*
*       _ForEach
*
* Purpose:
*   This routine hides/shows all windows except the button, graph and scroll bar widgets
*/
static void _ForEach(WM_HWIN hWin, void * pData)// _ToggleFullScreenMode??
{
	int Id, FullScreenMode;
	FullScreenMode = *(int *)pData;
	Id = WM_GetId(hWin);
	if ((Id == GUI_ID_GRAPH0) || (Id == GUI_ID_BUTTON0) || (Id == GUI_ID_VSCROLL) || (Id == GUI_ID_HSCROLL))
	{
		return;
	}
	if (FullScreenMode)
	{
		WM_HideWindow(hWin);
	}
	else {
		WM_ShowWindow(hWin);
	}
}

	

/*********************************************************************
*
*       _ToggleFullScreenMode
*
* Purpose:
*   This routine switches between full screen mode and normal mode by hiding or showing the
*   widgets of the dialog, enlarging/shrinking the graph widget and modifying some other
*   attributes of the dialog widgets.
*/
static void _ToggleFullScreenMode(WM_HWIN hDlg)
{
	static int	FullScreenMode;
	static GUI_RECT Rect;
	static unsigned ScalePos;
	WM_HWIN		hGraph, hButton;
	hGraph = WM_GetDialogItem(hDlg, GUI_ID_GRAPH0);
	hButton = WM_GetDialogItem(hDlg, GUI_ID_BUTTON0);
	FullScreenMode ^= 1;
	if (FullScreenMode)
	{
		/* Enter the full screen mode */
		WM_HWIN		hClient;
		GUI_RECT	RectInside;
		hClient = WM_GetClientWindow(hDlg);
		BUTTON_SetText(hButton, "Back");
		WM_MoveWindow(hButton, 0, 11);
		FRAMEWIN_SetTitleVis(hDlg, 0);
		WM_GetInsideRectEx(hClient, &RectInside);
		WM_GetWindowRectEx(hGraph, &Rect);
		WM_ForEachDesc(hClient, _ForEach, &FullScreenMode);                           /* Hide all descendants */
		WM_SetWindowPos(hGraph, WM_GetWindowOrgX(hClient), WM_GetWindowOrgX(hClient), RectInside.x1, RectInside.y1);
		ScalePos = GRAPH_SCALE_SetPos(_hScaleH, RectInside.y1 - 20);
	}
	else {
		/* Return to normal mode */
		BUTTON_SetText(hButton, "Full Screen");
		WM_MoveWindow(hButton, 0, -11);
		WM_ForEachDesc(WM_GetClientWindow(hDlg), _ForEach, &FullScreenMode);        /* Show all descendants */
		WM_SetWindowPos(hGraph, Rect.x0, Rect.y0, Rect.x1 - Rect.x0 + 1, Rect.y1 - Rect.y0 + 1);
		FRAMEWIN_SetTitleVis(hDlg, 1);
		GRAPH_SCALE_SetPos(_hScaleH, ScalePos);
	}
}


