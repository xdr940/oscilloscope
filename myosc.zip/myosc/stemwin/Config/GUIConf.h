
 
#ifndef GUICONF_H
#define GUICONF_H

#define GUI_NUM_LAYERS            1   // �����ʾ����

/*********************************************************************
*
*       Multi tasking support
*/

 #define GUI_OS                    (0)  // ��ʹ�ò���ϵͳ


/*********************************************************************
*
*       Configuration of touch support
*/

  #define GUI_SUPPORT_TOUCH       (1)  // ֧�ִ���


/*********************************************************************
*
*       Default font
*/
#define GUI_DEFAULT_FONT          &GUI_Font6x8//Ĭ������

/*********************************************************************
*
*         Configuration of available packages
*/
#define GUI_SUPPORT_MOUSE             (1)    /* ֧����� */
#define GUI_WINSUPPORT                (1)    /* ֧�ִ��ڹ��� */
#define GUI_SUPPORT_MEMDEV            (1)    /* ֧�ִ洢�豸 */
#define GUI_SUPPORT_DEVICES           (1)    /* ʹ���豸ָ�� */

#endif  /* Avoid multiple inclusion */
