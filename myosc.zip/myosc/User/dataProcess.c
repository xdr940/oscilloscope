//dataProcess.c


#include "dataProcess.h"


void interpolation(float * data2,int F,int size)
	{
		int i = 1;

		for (i = F / 2; i <= size - (F / 2); i += F)
		{
			data2[i] = .5 * (data2[i - F / 2] + data2[i + F / 2]);
		}
		if (F >= 4) {
			interpolation(data2, F / 2,size);
		}

		return;
	}
void initStructs(FrameData*frameData ,CurveStruct *curveStruct,int size){
		int i =0;
		frameData->vDiv = 1.25;
		frameData->timeBase= 1835;
		for(;i<size;i++){
				curveStruct->dataTemp[i]=0;
				curveStruct->data_f[i]=0;
				curveStruct->data_t[i]=0;
				curveStruct->data_t2[i]=0;
				curveStruct->dataTemp[i]=0;
		}
	


}
#define RAND_MAX 100
static unsigned long int next = 1;

int rand(void)    /* RAND_MAX assumed to be 32767*/
{
    next = next * 1103515245 + 12345;
    return   (next / 65536) % RAND_MAX  ;/* equal to (next / 65536) % 32768*/
}

float  Filter (float x,float *buf, int length){
		int i =0;
		float sum=0;
	for(i=0;i<length;i++){
		buf[length-i]=buf[length-i-1];
	}
	buf[0]=x;
	for(i=0;i<length;i++){
		sum+=buf[i];
	}
	return sum/length;
	

}
