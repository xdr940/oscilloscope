//main.h

#ifndef _MAIN_H
#define _MAIN_H


#include "stm32f4xx.h"
#include "bsp_usart.h"
#include "stdio.h"
#include "bsp_SysTick.h" 
#include "bsp_adc.h"
#include "osc.h"
#include "GUI.h"
//#include "bsp_SysTick.h"
#include "bsp_gt9157.h"
#include "bsp_lcd.h"

#include "DIALOG.h"
#include "GRAPH.h"

#include "bsp_fft.h"
#include "dataProcess.h"
#include "./tim/bsp_basic_tim.h"

/*********************************************************************
*
*       Defines
*
**********************************************************************
*/

#define MAX_VALUE	400                    /*?? */
#define MIN_VALUE	0
#define Wsize		1024                    /* ???? */
#define PointDisNum	1024                    /* ??????? */


#define GUI_ID_BUTTON10 (GUI_ID_USER + 0x0B)    /* ????????ID */
#define GUI_ID_BUTTON11 (GUI_ID_USER + 0x0C)    /* ????????ID */
#define GUI_ID_BUTTON12 (GUI_ID_USER + 0x0D)    /* ????????ID */
#define GUI_ID_BUTTON13 (GUI_ID_USER + 0x0E)
#define GUI_ID_BUTTON14 (GUI_ID_USER + 0x0F)



#define ID_TEXT_0 (GUI_ID_USER + 0x22)
#define ID_TEXT_1 (GUI_ID_USER + 0x23)
#define ID_TEXT_2 (GUI_ID_USER + 0x24)
#define ID_TEXT_3 (GUI_ID_USER + 0x25)
#define ID_TEXT_4 (GUI_ID_USER + 0x26)
#define ID_TEXT_5 (GUI_ID_USER + 0x27)
#define ID_TEXT_6 (GUI_ID_USER + 0x28)
#define ID_TEXT_7 (GUI_ID_USER + 0x29)
#define ID_TEXT_8 (GUI_ID_USER + 0x30)
#define ID_TEXT_9 (GUI_ID_USER + 0x3A)
#define ID_TEXT_10 (GUI_ID_USER + 0x3B)
#define ID_TEXT_11 (GUI_ID_USER + 0x3C)
#define ID_TEXT_12 (GUI_ID_USER + 0x3D)
#define ID_TEXT_13 (GUI_ID_USER + 0x3E)
#define ID_TEXT_14 (GUI_ID_USER + 0x3F)
#define ID_TEXT_15 (GUI_ID_USER + 0x40)
#define ID_TEXT_16 (GUI_ID_USER + 0x41)
#define ID_TEXT_17 (GUI_ID_USER + 0x42)
#define ID_TEXT_18 (GUI_ID_USER + 0x43)
#define ID_TEXT_19 (GUI_ID_USER + 0x44)
#define ID_TEXT_20 (GUI_ID_USER + 0x45)



#define SIZE		1024

#define TDOMAIN		0
#define FDOMAIN		1
#define TDOMAIN2    2//?????????
#define rel2pixStep 20
#define LENGTH 8;

/*********************************************************************
*
*       statics
*
*********************************************************************/
static GRAPH_DATA_Handle	_ahData[3];                                     /* Array of handles for the GRAPH_DATA objects */
static GRAPH_SCALE_Handle	_hScaleV;                                       /* Handle of vertical scale */
static GRAPH_SCALE_Handle	_hScaleH;                                       /* Handle of horizontal scale */
                                      /* ?????	-5~5											/ * ?n?????????,?? * / */

static GUI_COLOR		_aColor[] = { GUI_RED, GUI_GREEN, GUI_RED };       /* Array of colors for the GRAPH_DATA objects */
                                  /* time domain pix_t */

/*for signals*/																	   /* ?????	-5~5											/ * ?n?????????,?? * / */
static I8			_Stop;
static I8			_fft = 0;
static I8 Model=0;
static int				center = MAX_VALUE / 2;
static float				N = 1;
static float				rel2pix = 20;                          /* ????,?-5~5V ??? ???100??? */
static float trigVolts = 5;
static I8 timeBaseFactor = 1;            /* ?????? */
static double hScaleFac = .05;
static I8 NbrScaleNbr = 50;
static float vDivFac = 1;
static int t1,t2,t3,t4; //12 sampling 3 4 screen
float buf[8];//length
static __IO u32 delayus=0;

extern __IO uint32_t ADC_ConvertedValue[3];


static FrameData frameData;//???
static CurveStruct curveStruct;


static const GUI_WIDGET_CREATE_INFO	_aDialogCreate[] = {
	{ FRAMEWIN_CreateIndirect, "Framewin",	 0,		  0,   0,   800, 480, 0, 0x0, 0 },
	{ GRAPH_CreateIndirect,	   "Graph",		GUI_ID_GRAPH0,	  10,  10,  600, 400, 0, 0x0, 0 },
	
	{ BUTTON_CreateIndirect, "FFT", GUI_ID_BUTTON1, 310, 410, 50, 40, 0, 0x0, 0 },
	{ BUTTON_CreateIndirect, "START", GUI_ID_BUTTON2, 190, 410, 50, 40, 0, 0x0, 0 },
	{ BUTTON_CreateIndirect, "STOP", GUI_ID_BUTTON3, 250, 410, 50, 40, 0, 0x0, 0 },
	{ BUTTON_CreateIndirect, "Model", GUI_ID_BUTTON14, 70, 410, 50, 40, 0, 0x0, 0 },
	
	{ BUTTON_CreateIndirect,   "fullScreen", GUI_ID_BUTTON0,  650, 420, 100, 30,  0, 0x0, 0 },
	{ BUTTON_CreateIndirect,   "UP",		GUI_ID_BUTTON5,  620, 320, 50,	 40,  0, 0x0, 0 },
	{ BUTTON_CreateIndirect,   "DOWN",		GUI_ID_BUTTON6,  620, 370, 50,	 40,  0, 0x0, 0 },
	{ BUTTON_CreateIndirect,   "V/DIVU",	 GUI_ID_BUTTON7,  675, 320, 50,	 40,  0, 0x0, 0 },
	{ BUTTON_CreateIndirect,   "V/DIVD",	 GUI_ID_BUTTON8,  675, 370, 50,	 40,  0, 0x0, 0 },

	{ BUTTON_CreateIndirect,   "F/DIVD",	 GUI_ID_BUTTON10,  10,  410, 50,	 40,  0, 0x0, 0 },
	{ BUTTON_CreateIndirect,   "F/DIVU",	 GUI_ID_BUTTON9, 130, 410, 50,	 40,  0, 0x0, 0 },
	{ BUTTON_CreateIndirect,   "T/DIVU",	 GUI_ID_BUTTON11,730 , 320, 50, 40, 0, 0x0, 0 },
	{ BUTTON_CreateIndirect,   "T/DIVD",	 GUI_ID_BUTTON12,  730 , 370, 50, 40, 0, 0x0, 0 },
	
	{ BUTTON_CreateIndirect, "PrtSc",	GUI_ID_BUTTON13, 620, 295, 105, 20, 0, 0x0, 0 },
	{ LISTBOX_CreateIndirect, "Listbox",	 GUI_ID_LISTBOX0, 620, 221, 105, 70, 0, 0x0, 0 },
	{ MULTIEDIT_CreateIndirect, "graph2", GUI_ID_MULTIEDIT0, 620, 10, 160, 200, 0, 0x0, 0 },
	
	{ TEXT_CreateIndirect,		"maxTD:",			GUI_ID_TEXT0, 625, 15, 80, 20, 0, 0x64, 20 },
	{ TEXT_CreateIndirect,		"minTD	 :",	    GUI_ID_TEXT1, 625, 35, 80, 20, 0, 0x64, 0 },
	{ TEXT_CreateIndirect,		"ptp:",			GUI_ID_TEXT2, 625, 55, 80, 20, 0, 0x64, 0 },
	{ TEXT_CreateIndirect,		"mean:",				GUI_ID_TEXT3, 625, 75, 80, 20, 0, 0x64, 0 },

	{ TEXT_CreateIndirect,		"freq:",				GUI_ID_TEXT4, 625, 95, 80, 20, 0, 0x64, 0 },
	
	{ TEXT_CreateIndirect,		"Sa/s:",					GUI_ID_TEXT5, 625, 115,80, 20, 0, 0x64, 0 },
	{ TEXT_CreateIndirect,		"volts/div:",					GUI_ID_TEXT6, 625, 135,80, 20, 0, 0x64, 0 },
	{ TEXT_CreateIndirect,		"timeBase:",				GUI_ID_TEXT7, 625, 155,80, 20, 0, 0x64, 0 },
	{ TEXT_CreateIndirect,		"ScRefTime:",			GUI_ID_TEXT8, 625, 175,80, 20, 0, 0x64, 0 },
	{ TEXT_CreateIndirect,		"MODEL :",			GUI_ID_TEXT9, 625, 195,80, 20, 0, 0x64, 0 },
	//{ TEXT_CreateIndirect,		"ScRefTime:",			GUI_ID_TEXT9, 625, 195,80, 20, 0, 0x64, 0 },
};





/********************************************************
*						emwin functions
*
*******************************************************/

void _UserDraw( WM_HWIN hWin, int Stage );


void _updateValues( WM_HWIN hGraph ,FrameData*framedata,CurveStruct*curveStruct);
 void _updateFrameData(FrameData *frameData, CurveStruct*curveStruct);
void showData(WM_HWIN hDlg, FrameData* frameData);


void _cbCallback( WM_MESSAGE * pMsg );


static void _ToggleFullScreenMode(WM_HWIN hDlg);
 


#endif