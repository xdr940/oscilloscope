/**
  ******************************************************************************
  * @file    stm32f4xx_dcmi.h
  * @author  MCD Application Team
  * @version V1.5.1
  * @date    22-May-2015
  * @brief   This file contains all the functions prototypes for the DCMI firmware library.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2015 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STM32F4xx_DCMI_H
#define __STM32F4xx_DCMI_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"

/** @addtogroup STM32F4xx_StdPeriph_Driver
  * @{
  */

/** @addtogroup DCMI
  * @{
  */ 

/* Exported types ------------------------------------------------------------*/
/** 
  * @brief   DCMI Init structure definition  
  */ 
typedef struct
{
  uint16_t DCMI_CaptureMode;      /*!< Specifies the Capture(����) Mode: Continuous�������� or Snapshot�����գ�.
	                                      ָ������ģʽ������or����
                                       This parameter can be a value of @ref DCMI_Capture_Mode */

  uint16_t DCMI_SynchroMode;      /*!< Specifies the Synchronization��ͬ���� Mode: Hardware��Ӳ���� or Embedded����Ƕʽ��.
	                                     ָ��ͬ����ʽ��Ӳ��ͬ��or��Ƕ��ͬ��
                                       This parameter can be a value of @ref DCMI_Synchronization_Mode */

  uint16_t DCMI_PCKPolarity;      /*!< Specifies the Pixel clock polarity: Falling or Rising.
	                                     ָ������ʱ�Ӽ��ԣ�������or�½���
                                       This parameter can be a value of @ref DCMI_PIXCK_Polarity */

  uint16_t DCMI_VSPolarity;       /*!< Specifies the Vertical����ֱ�� synchronization polarity�����ԣ�: High or Low.
	                                     ָ����ֱͬ���źŵļ��ԣ��ߵ�ƽor�͵�ƽ
                                       This parameter can be a value of @ref DCMI_VSYNC_Polarity */

  uint16_t DCMI_HSPolarity;       /*!< Specifies the Horizontal��ˮƽ�� synchronization polarity: High or Low.
	                                     ָ��ˮƽͬ���źŵļ��ԣ��ߵ�ƽor�͵�ƽ
                                       This parameter can be a value of @ref DCMI_HSYNC_Polarity */

  uint16_t DCMI_CaptureRate;      /*!< Specifies the frequency��Ƶ�ʣ� of frame��֡�� capture: All, 1/2 or 1/4.
	                                     ָ��֡����Ƶ�ʣ�ȫ������  1/2   1/4
                                       This parameter can be a value of @ref DCMI_Capture_Rate */

  uint16_t DCMI_ExtendedDataMode; /*!< Specifies the data width: 8-bit, 10-bit, 12-bit or 14-bit.
	                                     ָ�����ݿ���
                                       This parameter can be a value of @ref DCMI_Extended_Data_Mode */
} DCMI_InitTypeDef;

/** 
  * @brief   DCMI CROP Init structure definition  
  */ 
typedef struct
{
  uint16_t DCMI_VerticalStartLine;      /*!< Specifies the Vertical start line count from which the image capture
	                                           ָ�����ڿ�ʼ������
                                             will start. This parameter can be a value between 0x00 and 0x1FFF */

  uint16_t DCMI_HorizontalOffsetCount;  /*!< Specifies the number of pixel clocks to count before starting a capture.
	                                           ָ����������ÿ�п�ʼ��Ҫ�ճ�������ʱ�Ӹ����������ڿ�ʼ������
                                             This parameter can be a value between 0x00 and 0x3FFF */

  uint16_t DCMI_VerticalLineCount;      /*!< Specifies the number of lines to be captured from the starting point.
	                                           �����ڰ���������
                                             This parameter can be a value between 0x00 and 0x3FFF */

  uint16_t DCMI_CaptureCount;           /*!< Specifies the number of pixel clocks to be captured from the starting
	                                           ������Ҫ��׽������ʱ����
                                             point on the same line.
                                             This parameter can be a value between 0x00 and 0x3FFF */
} DCMI_CROPInitTypeDef;

/** 
  * @brief   DCMI Embedded(��Ƕ) Synchronisation��ͬ���� CODE Init structure definition  
  */ 
typedef struct
{
  uint8_t DCMI_FrameStartCode; /*!< Specifies the code of the frame start delimiter���ָ�����. ֡��ʼ�ָ���*/
  uint8_t DCMI_LineStartCode;  /*!< Specifies the code of the line start delimiter. �п�ʼ�ָ���*/
  uint8_t DCMI_LineEndCode;    /*!< Specifies the code of the line end delimiter. �н����ָ���*/
  uint8_t DCMI_FrameEndCode;   /*!< Specifies the code of the frame end delimiter. ֡�����ָ���*/
} DCMI_CodesInitTypeDef;

/* Exported constants --------------------------------------------------------*/

/** @defgroup DCMI_Exported_Constants
  * @{
  */

/** @defgroup DCMI_Capture_Mode 
  * @{
  */ 
#define DCMI_CaptureMode_Continuous    ((uint16_t)0x0000) /*!< The received�����գ� data are transferred��ת���� continuously���������ϣ�   
                                                               �����ɼ�ģʽ
                                                               into the destination��Ŀ�ĵأ� memory through the DMA */
#define DCMI_CaptureMode_SnapShot      ((uint16_t)0x0002) /*!< Once activated, the interface waits for the start of  
                                                               ����ģʽ����֡��
                                                               frame and then transfers a single frame through the DMA */
#define IS_DCMI_CAPTURE_MODE(MODE)(((MODE) == DCMI_CaptureMode_Continuous) || \
                                   ((MODE) == DCMI_CaptureMode_SnapShot))
/**
  * @}
  */ 


/** @defgroup DCMI_Synchronization_Mode
  * @{
  */ 
#define DCMI_SynchroMode_Hardware    ((uint16_t)0x0000) /*!< Hardware synchronization data capture (frame/line start/stop)   Ӳ��ģʽ
                                                             is synchronized with the HSYNC/VSYNC signals */ 
#define DCMI_SynchroMode_Embedded    ((uint16_t)0x0010) /*!< Embedded synchronization data capture is synchronized with     ��Ƕ��ģʽ
                                                             synchronization codes embedded in the data flow */
#define IS_DCMI_SYNCHRO(MODE)(((MODE) == DCMI_SynchroMode_Hardware) || \
                              ((MODE) == DCMI_SynchroMode_Embedded))
/**
  * @}
  */ 


/** @defgroup DCMI_PIXCK_Polarity 
  * @{
  */ 
#define DCMI_PCKPolarity_Falling    ((uint16_t)0x0000) /*!< Pixel clock active on Falling edge   ����ʱ���½�����Ч*/
#define DCMI_PCKPolarity_Rising     ((uint16_t)0x0020) /*!< Pixel clock active on Rising edge    ����ʱ����������Ч*/
#define IS_DCMI_PCKPOLARITY(POLARITY)(((POLARITY) == DCMI_PCKPolarity_Falling) || \
                                      ((POLARITY) == DCMI_PCKPolarity_Rising))
/**
  * @}
  */ 


/** @defgroup DCMI_VSYNC_Polarity 
  * @{
  */ 
#define DCMI_VSPolarity_Low     ((uint16_t)0x0000) /*!< Vertical synchronization active Low ֡ͬ����VSYC���͵�ƽ��Ч*/
#define DCMI_VSPolarity_High    ((uint16_t)0x0080) /*!< Vertical synchronization active High ֡ͬ����VSYC���ߵ�ƽ��Ч*/
#define IS_DCMI_VSPOLARITY(POLARITY)(((POLARITY) == DCMI_VSPolarity_Low) || \
                                     ((POLARITY) == DCMI_VSPolarity_High))
/**
  * @}
  */ 


/** @defgroup DCMI_HSYNC_Polarity 
  * @{
  */ 
#define DCMI_HSPolarity_Low     ((uint16_t)0x0000) /*!< Horizontal synchronization active Low ��ͬ����HSYNC���͵�ƽ��Ч*/
#define DCMI_HSPolarity_High    ((uint16_t)0x0040) /*!< Horizontal synchronization active High ��ͬ����HSYNC���ߵ�ƽ��Ч*/
#define IS_DCMI_HSPOLARITY(POLARITY)(((POLARITY) == DCMI_HSPolarity_Low) || \
                                     ((POLARITY) == DCMI_HSPolarity_High))
/**
  * @}
  */ 


/** @defgroup DCMI_Capture_Rate 
  * @{
  */ 
#define DCMI_CaptureRate_All_Frame     ((uint16_t)0x0000) /*!< All frames are captured     ��������֡ */
#define DCMI_CaptureRate_1of2_Frame    ((uint16_t)0x0100) /*!< Every��ÿ���� alternate�����棩 frame captured   ÿ 2 ֡����һ֡*/
#define DCMI_CaptureRate_1of4_Frame    ((uint16_t)0x0200) /*!< One frame in 4 frames captured         ÿ�� 4 ֡����һ֡ */
#define IS_DCMI_CAPTURE_RATE(RATE) (((RATE) == DCMI_CaptureRate_All_Frame) || \
                                    ((RATE) == DCMI_CaptureRate_1of2_Frame) ||\
                                    ((RATE) == DCMI_CaptureRate_1of4_Frame))
/**
  * @}
  */ 


/** @defgroup DCMI_Extended_Data_Mode 
  * @{
  */ 
#define DCMI_ExtendedDataMode_8b     ((uint16_t)0x0000) /*!< Interface captures 8-bit data on every pixel clock  �����߿���Ϊ8λ*/
#define DCMI_ExtendedDataMode_10b    ((uint16_t)0x0400) /*!< Interface captures 10-bit data on every pixel clock  �����߿���Ϊ10λ*/
#define DCMI_ExtendedDataMode_12b    ((uint16_t)0x0800) /*!< Interface captures 12-bit data on every pixel clock  �����߿���Ϊ12λ*/
#define DCMI_ExtendedDataMode_14b    ((uint16_t)0x0C00) /*!< Interface captures 14-bit data on every pixel clock  �����߿���Ϊ14λ*/
#define IS_DCMI_EXTENDED_DATA(DATA)(((DATA) == DCMI_ExtendedDataMode_8b) || \
                                    ((DATA) == DCMI_ExtendedDataMode_10b) ||\
                                    ((DATA) == DCMI_ExtendedDataMode_12b) ||\
                                    ((DATA) == DCMI_ExtendedDataMode_14b))
/**
  * @}
  */ 


/** @defgroup DCMI_interrupt_sources 
  * @{
  */ 
#define DCMI_IT_FRAME    ((uint16_t)0x0001)//��ʾ֡�������
#define DCMI_IT_OVF      ((uint16_t)0x0002)//��ʾ���յ����ݷ����������
#define DCMI_IT_ERR      ((uint16_t)0x0004)//��ʾ��Ƕ��ͬ��֡����ڼ��⵽����
#define DCMI_IT_VSYNC    ((uint16_t)0x0008)//��ʾͬ��֡
#define DCMI_IT_LINE     ((uint16_t)0x0010)//��ʾ�н���
#define IS_DCMI_CONFIG_IT(IT) ((((IT) & (uint16_t)0xFFE0) == 0x0000) && ((IT) != 0x0000))
#define IS_DCMI_GET_IT(IT) (((IT) == DCMI_IT_FRAME) || \
                            ((IT) == DCMI_IT_OVF) || \
                            ((IT) == DCMI_IT_ERR) || \
                            ((IT) == DCMI_IT_VSYNC) || \
                            ((IT) == DCMI_IT_LINE))
/**
  * @}
  */ 


/** @defgroup DCMI_Flags 
  * @{
  */ 
/** 
  * @brief   DCMI SR register  
  */ 
#define DCMI_FLAG_HSYNC     ((uint16_t)0x2001)//��λָʾ������ʵ����Ե� HSYNC ���ŵ�״̬��
#define DCMI_FLAG_VSYNC     ((uint16_t)0x2002)//��λָʾ������ʵ����Ե� VSYNC ���ŵ�״̬
#define DCMI_FLAG_FNE       ((uint16_t)0x2004)//FIFO �ǿ� 
/** 
  * @brief   DCMI RISR register  
  */ 
#define DCMI_FLAG_FRAMERI    ((uint16_t)0x0001)//������ɱ�־ԭʼ�ж�״̬
#define DCMI_FLAG_OVFRI      ((uint16_t)0x0002)//�����־ԭʼ�ж�״̬
#define DCMI_FLAG_ERRRI      ((uint16_t)0x0004)//ͬ������ԭʼ�ж�״̬
#define DCMI_FLAG_VSYNCRI    ((uint16_t)0x0008)//VSYNC ԭʼ�ж�״̬
#define DCMI_FLAG_LINERI     ((uint16_t)0x0010)//��ԭʼ�ж�״̬
/** 
  * @brief   DCMI MISR register  
  */ 
#define DCMI_FLAG_FRAMEMI    ((uint16_t)0x1001)//�������ж�״̬
#define DCMI_FLAG_OVFMI      ((uint16_t)0x1002)//VSYNC �����ж�״̬
#define DCMI_FLAG_ERRMI      ((uint16_t)0x1004)//ͬ�����������ж�״̬
#define DCMI_FLAG_VSYNCMI    ((uint16_t)0x1008)//��������ж�״̬ 
#define DCMI_FLAG_LINEMI     ((uint16_t)0x1010)//������������ж�״̬ 
#define IS_DCMI_GET_FLAG(FLAG) (((FLAG) == DCMI_FLAG_HSYNC) || \
                                ((FLAG) == DCMI_FLAG_VSYNC) || \
                                ((FLAG) == DCMI_FLAG_FNE) || \
                                ((FLAG) == DCMI_FLAG_FRAMERI) || \
                                ((FLAG) == DCMI_FLAG_OVFRI) || \
                                ((FLAG) == DCMI_FLAG_ERRRI) || \
                                ((FLAG) == DCMI_FLAG_VSYNCRI) || \
                                ((FLAG) == DCMI_FLAG_LINERI) || \
                                ((FLAG) == DCMI_FLAG_FRAMEMI) || \
                                ((FLAG) == DCMI_FLAG_OVFMI) || \
                                ((FLAG) == DCMI_FLAG_ERRMI) || \
                                ((FLAG) == DCMI_FLAG_VSYNCMI) || \
                                ((FLAG) == DCMI_FLAG_LINEMI))
                                
#define IS_DCMI_CLEAR_FLAG(FLAG) ((((FLAG) & (uint16_t)0xFFE0) == 0x0000) && ((FLAG) != 0x0000))
/**
  * @}
  */ 

/**
  * @}
  */ 

/* Exported macro ------------------------------------------------------------*/
/* Exported functions --------------------------------------------------------*/ 

/*  Function used to set the DCMI configuration to the default reset state ****/ 
void DCMI_DeInit(void);//��λDCMI

/* Initialization and Configuration functions *********************************/
void DCMI_Init(DCMI_InitTypeDef* DCMI_InitStruct);                             //��ʼ��DCMI
void DCMI_StructInit(DCMI_InitTypeDef* DCMI_InitStruct);                       //��� DCMI_InitStruct �ṹ��ΪĬ��ֵ
void DCMI_CROPConfig(DCMI_CROPInitTypeDef* DCMI_CROPInitStruct);               //��ʼ�� DCMI �Ĳü�����
void DCMI_CROPCmd(FunctionalState NewState);                                   //ʹ�ܲü�����
void DCMI_SetEmbeddedSynchroCodes(DCMI_CodesInitTypeDef* DCMI_CodesInitStruct);//������Ƕ��ͬ��
void DCMI_JPEGCmd(FunctionalState NewState);                                   //JPEG ��ʽ����ʹ��

/* Image capture functions ****************************************************/
void DCMI_Cmd(FunctionalState NewState);        //DCMI ʹ��
void DCMI_CaptureCmd(FunctionalState NewState); //DCMI ����ʹ��
uint32_t DCMI_ReadData(void);                   //��DCMI ����

/* Interrupts and flags management functions **********************************/
void DCMI_ITConfig(uint16_t DCMI_IT, FunctionalState NewState);//DCMI �ж�����
FlagStatus DCMI_GetFlagStatus(uint16_t DCMI_FLAG);             //��ȡָ����־λ��״̬
void DCMI_ClearFlag(uint16_t DCMI_FLAG);                       //�����־λ
ITStatus DCMI_GetITStatus(uint16_t DCMI_IT);                   //���ָ���ж��Ƿ���
void DCMI_ClearITPendingBit(uint16_t DCMI_IT);                 //����жϹ���λ

#ifdef __cplusplus
}
#endif

#endif /*__STM32F4xx_DCMI_H */

/**
  * @}
  */ 

/**
  * @}
  */ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
