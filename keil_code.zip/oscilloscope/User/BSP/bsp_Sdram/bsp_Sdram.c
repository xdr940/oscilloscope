#include "./bsp_Sdram/bsp_Sdram.h" 

/*
*����˵������ʼ������
*/
static void SRAM_GPIO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	                       /*��ַ��*/
	RCC_AHB1PeriphClockCmd(FMC_A0_CLK | FMC_A1_CLK | FMC_A2_CLK |FMC_A3_CLK | 
                         FMC_A4_CLK | FMC_A5_CLK |FMC_A6_CLK | FMC_A7_CLK |
                         FMC_A8_CLK |FMC_A9_CLK | FMC_A10_CLK| FMC_A11_CLK|                      
		                     /*bank��ַ��*/
		                     FMC_B0_CLK |FMC_B1_CLK |		                     
		                     /*������*/
		                     FMC_D0_CLK | FMC_D1_CLK | FMC_D2_CLK |FMC_D3_CLK | 
                         FMC_D4_CLK | FMC_D5_CLK |FMC_D6_CLK | FMC_D7_CLK |
                         FMC_D8_CLK |FMC_D9_CLK | FMC_D10_CLK| FMC_D11_CLK|
                         FMC_D12_CLK| FMC_D13_CLK| FMC_D14_CLK|FMC_D15_CLK|  	 
		                     /*������*/
		                     FMC_CS_CLK |FMC_WE_CLK |FMC_RAS_CLK |FMC_CAS_CLK|
		                     FMC_CLK_CLK|FMC_CKE_CLK|FMC_LDQM_CLK|FMC_UDQM_CLK            
		                    ,ENABLE);
	
  GPIO_InitStruct.GPIO_Mode  = GPIO_Mode_AF;       //ʹ�ø��ù���
  GPIO_InitStruct.GPIO_Speed = GPIO_Fast_Speed;    //����
  GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;      //�������
  GPIO_InitStruct.GPIO_PuPd  = GPIO_PuPd_NOPULL;   //��������
	/*��ַ��*/
	/*A0*/
	GPIO_InitStruct.GPIO_Pin = FMC_A0_PIN; 
	GPIO_Init( FMC_A0_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_A0_PORT, FMC_A0_PINSOURCE , FMC_A0_AF);
	/*A1*/
	GPIO_InitStruct.GPIO_Pin = FMC_A1_PIN; 
	GPIO_Init( FMC_A1_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_A1_PORT, FMC_A1_PINSOURCE , FMC_A1_AF);
	/*A2*/
	GPIO_InitStruct.GPIO_Pin = FMC_A2_PIN; 
	GPIO_Init( FMC_A2_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_A2_PORT, FMC_A2_PINSOURCE , FMC_A2_AF);
	/*A3*/
	GPIO_InitStruct.GPIO_Pin = FMC_A3_PIN; 
	GPIO_Init( FMC_A3_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_A3_PORT, FMC_A3_PINSOURCE , FMC_A3_AF);
	/*A4*/
	GPIO_InitStruct.GPIO_Pin = FMC_A4_PIN; 
	GPIO_Init( FMC_A4_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_A4_PORT, FMC_A4_PINSOURCE , FMC_A4_AF);
	/*A5*/
	GPIO_InitStruct.GPIO_Pin = FMC_A5_PIN; 
	GPIO_Init( FMC_A5_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_A5_PORT, FMC_A5_PINSOURCE , FMC_A5_AF);
	/*A6*/
	GPIO_InitStruct.GPIO_Pin = FMC_A6_PIN; 
	GPIO_Init( FMC_A6_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_A6_PORT, FMC_A6_PINSOURCE , FMC_A6_AF);
	/*A7*/
	GPIO_InitStruct.GPIO_Pin = FMC_A7_PIN; 
	GPIO_Init( FMC_A7_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_A7_PORT, FMC_A7_PINSOURCE , FMC_A7_AF);
	/*A8*/
	GPIO_InitStruct.GPIO_Pin = FMC_A8_PIN; 
	GPIO_Init( FMC_A8_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_A8_PORT, FMC_A8_PINSOURCE , FMC_A8_AF);
	/*A9*/
	GPIO_InitStruct.GPIO_Pin = FMC_A9_PIN; 
	GPIO_Init( FMC_A9_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_A9_PORT, FMC_A9_PINSOURCE , FMC_A9_AF);
	/*A10*/
	GPIO_InitStruct.GPIO_Pin = FMC_A10_PIN; 
	GPIO_Init( FMC_A10_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_A10_PORT, FMC_A10_PINSOURCE , FMC_A10_AF);
	/*A11*/
	GPIO_InitStruct.GPIO_Pin = FMC_A11_PIN; 
	GPIO_Init( FMC_A11_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_A11_PORT, FMC_A11_PINSOURCE , FMC_A11_AF);
	/*������*/
	/*D0*/
	GPIO_InitStruct.GPIO_Pin = FMC_D0_PIN; 
	GPIO_Init( FMC_D0_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_D0_PORT, FMC_D0_PINSOURCE , FMC_D0_AF);
	/*D1*/
	GPIO_InitStruct.GPIO_Pin = FMC_D1_PIN; 
	GPIO_Init( FMC_D1_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_D1_PORT, FMC_D1_PINSOURCE , FMC_D1_AF);
	/*D2*/
	GPIO_InitStruct.GPIO_Pin = FMC_D2_PIN; 
	GPIO_Init( FMC_D2_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_D2_PORT, FMC_D2_PINSOURCE , FMC_D2_AF);
	/*D3*/
	GPIO_InitStruct.GPIO_Pin = FMC_D3_PIN; 
	GPIO_Init( FMC_D3_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_D3_PORT, FMC_D3_PINSOURCE , FMC_D3_AF);
	/*D4*/
	GPIO_InitStruct.GPIO_Pin = FMC_D4_PIN; 
	GPIO_Init( FMC_D4_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_D4_PORT, FMC_D4_PINSOURCE , FMC_D4_AF);
	/*D5*/
	GPIO_InitStruct.GPIO_Pin = FMC_D5_PIN; 
	GPIO_Init( FMC_D5_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_D5_PORT, FMC_D5_PINSOURCE , FMC_D5_AF);
	/*D6*/
	GPIO_InitStruct.GPIO_Pin = FMC_D6_PIN; 
	GPIO_Init( FMC_D6_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_D6_PORT, FMC_D6_PINSOURCE , FMC_D6_AF);
	/*D7*/
	GPIO_InitStruct.GPIO_Pin = FMC_D7_PIN; 
	GPIO_Init( FMC_D7_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_D7_PORT, FMC_D7_PINSOURCE , FMC_D7_AF);
	/*D8*/
	GPIO_InitStruct.GPIO_Pin = FMC_D8_PIN; 
	GPIO_Init( FMC_D8_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_D8_PORT, FMC_D8_PINSOURCE , FMC_D8_AF);
	/*D9*/
	GPIO_InitStruct.GPIO_Pin = FMC_D9_PIN; 
	GPIO_Init( FMC_D9_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_D9_PORT, FMC_D9_PINSOURCE , FMC_D9_AF);
	/*D10*/
	GPIO_InitStruct.GPIO_Pin = FMC_D10_PIN; 
	GPIO_Init( FMC_D10_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_D10_PORT, FMC_D10_PINSOURCE , FMC_D10_AF);
	/*D11*/
	GPIO_InitStruct.GPIO_Pin = FMC_D11_PIN; 
	GPIO_Init( FMC_D11_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_D11_PORT, FMC_D11_PINSOURCE , FMC_D11_AF);
	/*D12*/
	GPIO_InitStruct.GPIO_Pin = FMC_D12_PIN; 
	GPIO_Init( FMC_D12_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_D12_PORT, FMC_D12_PINSOURCE , FMC_D12_AF);
	/*D13*/
	GPIO_InitStruct.GPIO_Pin = FMC_D13_PIN; 
	GPIO_Init( FMC_D13_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_D13_PORT, FMC_D13_PINSOURCE , FMC_D13_AF);
	/*D14*/
	GPIO_InitStruct.GPIO_Pin = FMC_D14_PIN; 
	GPIO_Init( FMC_D14_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_D14_PORT, FMC_D14_PINSOURCE , FMC_D14_AF);
	/*D15*/
	GPIO_InitStruct.GPIO_Pin = FMC_D15_PIN; 
	GPIO_Init( FMC_D15_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_D15_PORT, FMC_D15_PINSOURCE , FMC_D15_AF);
  /*SDRAM�� bank ��ַ��*/
	/*B0*/
	GPIO_InitStruct.GPIO_Pin = FMC_B0_PIN; 
	GPIO_Init( FMC_B0_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_B0_PORT, FMC_B0_PINSOURCE , FMC_B0_AF);
	/*B1*/
	GPIO_InitStruct.GPIO_Pin = FMC_B1_PIN; 
	GPIO_Init( FMC_B1_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_B1_PORT, FMC_B1_PINSOURCE , FMC_B1_AF);
	/*������*/
	/*CS*/
	GPIO_InitStruct.GPIO_Pin = FMC_CS_PIN; 
	GPIO_Init( FMC_CS_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_CS_PORT, FMC_CS_PINSOURCE , FMC_CS_AF);
  /*WE*/
  GPIO_InitStruct.GPIO_Pin = FMC_WE_PIN; 
	GPIO_Init( FMC_WE_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_WE_PORT, FMC_WE_PINSOURCE , FMC_WE_AF);
	/*RAS*/
	GPIO_InitStruct.GPIO_Pin = FMC_RAS_PIN; 
	GPIO_Init( FMC_RAS_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_RAS_PORT, FMC_RAS_PINSOURCE , FMC_RAS_AF);
	/*CAS*/
	GPIO_InitStruct.GPIO_Pin = FMC_CAS_PIN; 
	GPIO_Init( FMC_CAS_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_CAS_PORT, FMC_CAS_PINSOURCE , FMC_CAS_AF);
	/*CLK*/
	GPIO_InitStruct.GPIO_Pin = FMC_CLK_PIN; 
	GPIO_Init( FMC_CLK_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_CLK_PORT, FMC_CLK_PINSOURCE , FMC_CLK_AF);
	/*CKE*/
	GPIO_InitStruct.GPIO_Pin = FMC_CKE_PIN; 
	GPIO_Init( FMC_CKE_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_CKE_PORT, FMC_CKE_PINSOURCE , FMC_CKE_AF);
	/*LDQM*/
	GPIO_InitStruct.GPIO_Pin = FMC_LDQM_PIN; 
	GPIO_Init( FMC_LDQM_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_LDQM_PORT, FMC_LDQM_PINSOURCE , FMC_LDQM_AF);
	/*UDQM*/
	GPIO_InitStruct.GPIO_Pin = FMC_UDQM_PIN; 
	GPIO_Init( FMC_UDQM_PORT  , &GPIO_InitStruct);
	GPIO_PinAFConfig(FMC_UDQM_PORT, FMC_UDQM_PINSOURCE , FMC_UDQM_AF);
	
}



/*
*����˵������ʼ��SDRAM
*/
static void SDRAM_InitSequence(void)
{
	FMC_SDRAMCommandTypeDef FMC_SDRAMCommandStruct;
	uint32_t i=0;
	/* �����ṩ��SDRAM��ʱ�� */
  FMC_SDRAMCommandStruct.FMC_CommandMode             =FMC_Command_Mode_CLK_Enabled;     /* ʹ�� CLK  */                                            
  FMC_SDRAMCommandStruct.FMC_CommandTarget           =FMC_Command_Target_bank2;         /*FMC��bank2���� */                                            
  FMC_SDRAMCommandStruct.FMC_AutoRefreshNumber       =1;                                /* �˲�����1����16֮��*/                                                                                                                                                     
  FMC_SDRAMCommandStruct.FMC_ModeRegisterDefinition  =0;                                /*������ó�Ա��Ч*/
	for(i=0xffff; (FMC_GetFlagStatus(FMC_Bank2_SDRAM, FMC_FLAG_Busy)==SET) && (i>0);i--); /*�ȴ� SDRAM ����������*/
	if(i==0){printf("�ȴ� SDRAM ���������г�ʱ\n");return;}
	FMC_SDRAMCmdConfig(&FMC_SDRAMCommandStruct);  /*д����������*/
	/*��ʱ*/
	for(i =0x1ffffff ; i> 0; i--){}                        
	/* Ԥ������� */
  FMC_SDRAMCommandStruct.FMC_CommandMode             =FMC_Command_Mode_PALL;           /* Ԥ��� */                                            
  FMC_SDRAMCommandStruct.FMC_CommandTarget           =FMC_Command_Target_bank2;        /*FMC��bank2���� */                                            
  FMC_SDRAMCommandStruct.FMC_AutoRefreshNumber       =1;                               /* �˲�����1����16֮��*/                                                                                                                                                     
  FMC_SDRAMCommandStruct.FMC_ModeRegisterDefinition  =0;                               /*������ó�Ա��Ч*/
	for(i=0xffff; (FMC_GetFlagStatus(FMC_Bank2_SDRAM, FMC_FLAG_Busy)==SET) && (i>0);i--);/*�ȴ� SDRAM ����������*/
	if(i==0){printf("�ȴ� SDRAM ���������г�ʱ\n");return;}
	FMC_SDRAMCmdConfig(&FMC_SDRAMCommandStruct);  /*д����������*/
	/* �Զ�ˢ�� */
  FMC_SDRAMCommandStruct.FMC_CommandMode             =FMC_Command_Mode_AutoRefresh;    /* �Զ�ˢ������  */                                            
  FMC_SDRAMCommandStruct.FMC_CommandTarget           =FMC_Command_Target_bank2;        /*FMC��bank2���� */                                            
  FMC_SDRAMCommandStruct.FMC_AutoRefreshNumber       =2;                               /*�Զ�ˢ��2��*/                                                                                                                                                     
  FMC_SDRAMCommandStruct.FMC_ModeRegisterDefinition  =0;                               /*������ó�Ա��Ч*/
	for(i=0xffff; (FMC_GetFlagStatus(FMC_Bank2_SDRAM, FMC_FLAG_Busy)==SET) && (i>0);i--);   /*�ȴ� SDRAM ����������*/
	if(i==0){printf("�ȴ� SDRAM ���������г�ʱ\n");return;}
	FMC_SDRAMCmdConfig(&FMC_SDRAMCommandStruct);  /*д����������*/
	
	
	/* ����SDRAM��ģʽ�Ĵ��� */
  FMC_SDRAMCommandStruct.FMC_CommandMode             =FMC_Command_Mode_LoadMode;        /* ����ģʽ�Ĵ�������  */                                            
  FMC_SDRAMCommandStruct.FMC_CommandTarget           =FMC_Command_Target_bank2;         /*FMC��bank2���� */                                            
  FMC_SDRAMCommandStruct.FMC_AutoRefreshNumber       =1;                                /* �˲�����1����16֮��*/                                                                                                                                                     
  FMC_SDRAMCommandStruct.FMC_ModeRegisterDefinition  =0x222;                            /*SDRAM��ģʽ�Ĵ���*/
	for(i=0xffff; (FMC_GetFlagStatus(FMC_Bank2_SDRAM, FMC_FLAG_Busy)==SET) && (i>0);i--); /*�ȴ� SDRAM ����������*/
	if(i==0){printf("�ȴ� SDRAM ���������г�ʱ\n");return;}
	FMC_SDRAMCmdConfig(&FMC_SDRAMCommandStruct);  /*д����������*/
	/* ����ˢ������ */
	FMC_SetRefreshCount(1386);                             //SDRAMˢ������ 
	for(i=0xffff; (FMC_GetFlagStatus(FMC_Bank2_SDRAM, FMC_FLAG_Busy)==SET) && (i>0);i--);   /*�ȴ� SDRAM ����������*/
	if(i==0){printf("�ȴ� SDRAM ���������г�ʱ\n");return;}
	
}


/*
*����˵������ʼ��SDRAM��FMC
*/
void SDRAM_Init(void)
{
	FMC_SDRAMInitTypeDef       FMC_SDRAMInitStruct;  //��ʼ���ṹ��
	FMC_SDRAMTimingInitTypeDef FMC_SDRAMtimingStruct;//ʱ��ṹ��
	RCC_AHB3PeriphClockCmd(RCC_AHB3Periph_FMC, ENABLE);//����FMCʱ��
	SRAM_GPIO_Init();                                  //��ʼ��FMC����
	/*ʱ��ṹ��,SDCLK=90M,Tsdclk=11.111ns*/
	FMC_SDRAMtimingStruct.FMC_LoadToActiveDelay   =2;     /*TMRD:����ģʽ�Ĵ����������ӳ� */  
  FMC_SDRAMtimingStruct.FMC_ExitSelfRefreshDelay=7;     /*TXSR:��ˢ���������ӳ�. */   
  FMC_SDRAMtimingStruct.FMC_SelfRefreshTime     =4;     /*TRAS:��ˢ��ʱ��. */                                            
  FMC_SDRAMtimingStruct.FMC_RowCycleDelay       =7;     /*TRC :��ѭ���ӳ� */                                            
  FMC_SDRAMtimingStruct.FMC_WriteRecoveryTime   =2;     /*TWR :�ָ��ӳ� */                                            
  FMC_SDRAMtimingStruct.FMC_RPDelay             =2;     /*TRP :��Ԥ����ӳ� */                                           
  FMC_SDRAMtimingStruct.FMC_RCDDelay            =2;     /*TRCD:�е����ӳ� */
	/*��ʼ���ṹ��*/
	FMC_SDRAMInitStruct.FMC_Bank                  =FMC_Bank2_SDRAM;               /*ѡ�� FMC ��FMC��Bank2���� */
  FMC_SDRAMInitStruct.FMC_ColumnBitsNumber      =FMC_ColumnBits_Number_8b;      /* 8λ�е�ַ�е�ַ���� */                                            
  FMC_SDRAMInitStruct.FMC_RowBitsNumber         =FMC_RowBits_Number_12b;        /*12λ�е�ַ�е�ַ���� */                                            
  FMC_SDRAMInitStruct.FMC_SDMemoryDataWidth     =FMC_SDMemory_Width_16b;        /*SDRAMΪ16λ���� */                                            
  FMC_SDRAMInitStruct.FMC_InternalBankNumber    =FMC_InternalBank_Number_4;     /*SDRAM�ڲ���4��Bank*/                                            
  FMC_SDRAMInitStruct.FMC_CASLatency            =FMC_CAS_Latency_2;             /*CASΪ2��SDCLK,Ҫ��SDRAM������һ�¡� */                                            
  FMC_SDRAMInitStruct.FMC_WriteProtection       =FMC_Write_Protection_Disable;  /*д������ֹ*/                                            
  FMC_SDRAMInitStruct.FMC_SDClockPeriod         =FMC_SDClock_Period_2;          /*SDCLK=HCLK/2,Ϊ90M */                                            
  FMC_SDRAMInitStruct.FMC_ReadBurst             =FMC_Read_Burst_Enable;         /*  ʹ��ͻ����ģʽ*/                                           
  FMC_SDRAMInitStruct.FMC_ReadPipeDelay         =FMC_ReadPipe_Delay_0;          /*�� CAS ���ӳٺ����Ӻ� 0 �� HCLK ʱ�� */                                            
  FMC_SDRAMInitStruct.FMC_SDRAMTimingStruct     =&FMC_SDRAMtimingStruct;        /*���� SDRAM ��ʱ�����*/   
	 /*��ʼ�� FMC */
	FMC_SDRAMInit(&FMC_SDRAMInitStruct); 
	SDRAM_InitSequence();  //����ʼ�����̳�ʼ��SDRAM

}



/**
  * @brief  ����SDRAM�Ƿ����� 
  * @param  None
  * @retval ��������0���쳣����1
  */
uint8_t SDRAM_Test(void)
{
	uint8_t k=0;
  uint32_t i;//��ȡ������
	printf("\n8λ���ݶ�д����\n");
	uint8_t *test1=(uint8_t*)SDRAM_START_ADDR;
	for(i=0;i<SDRAM_SIZE;i++)//д��
	{
		*test1=(uint8_t)i;
		test1++;
	}
	test1=(uint8_t*)SDRAM_START_ADDR;//ָ�븴λ
	for(i=0;i<SDRAM_SIZE;i++)//�������Ƚ�
	{
		if(*test1==(uint8_t)i)
		test1++;
		else
		{
			printf("8λ���ݶ�д����ʧ��\n");
			k=1;
			break;
		}
	}
	if(i==SDRAM_SIZE)printf("8λ���ݶ�д���Գɹ�\n");
	
	printf("\n16λ���ݶ�д����\n");
	uint16_t *test2=(uint16_t*)SDRAM_START_ADDR;
	for(i=0;i<SDRAM_SIZE/2;i++)//д��
	{
		*test2=(uint16_t)i;
		test2++;
	}
	test2=(uint16_t*)SDRAM_START_ADDR;//ָ�븴λ
	for(i=0;i<SDRAM_SIZE/2;i++)//�������Ƚ�
	{
		if(*test2==(uint16_t)i)
		test2++;
		else
		{
			printf("16λ���ݶ�д����ʧ��\n");
			k=1;
			break;
		}
	}
	if(i==SDRAM_SIZE/2)printf("16λ���ݶ�д���Գɹ�\n");
	
	printf("\n32λ���ݶ�д����\n");
	uint32_t *test3=(uint32_t*)SDRAM_START_ADDR;
	for(i=0;i<SDRAM_SIZE/4;i++)//д��
	{
		*test3=(uint32_t)(i+0xfffff);
		test3++;
	}
	test3=(uint32_t*)SDRAM_START_ADDR;//ָ�븴λ
	for(i=0;i<SDRAM_SIZE/4;i++)//�������Ƚ�
	{
		if(*test3==(uint32_t)(i+0xfffff))
		test3++;
		else
		{
			printf("32λ���ݶ�д����ʧ��\n");
			k=1;
			break;
		}
	}
	if(i==SDRAM_SIZE/4)printf("32λ���ݶ�д���Գɹ�\n");
	return k;
}

