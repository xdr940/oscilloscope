
#ifndef _FFT_H_
#define	_FFT_H_
#include "stm32f4xx.h"
#include <math.h>


#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#define SIZE 512
#define VALUE_MAX 600

struct Complex_ {
	float real;
	float imagin;
};

typedef struct Complex_ Complex;

void abs_Complex(Complex *src, float *dst);
void FFT(float * src, Complex * dst, int size_n);
#endif
