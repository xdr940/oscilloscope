


/************************************

							FFT CODES

*************************************/
#include "./FFT/FFT.h"





 void abs_Complex(Complex *src, float *dst) {
	int i = 0;
	for (i = 0; i<SIZE; i++) {
		dst[i] = sqrt(pow(src[i].real, 2) + pow(src[i].imagin, 2));

	}

}
static void  Add_Complex(Complex * src1, Complex *src2, Complex *dst) {
	dst->imagin = src1->imagin + src2->imagin;
	dst->real = src1->real + src2->real;
}

static void Sub_Complex(Complex * src1, Complex *src2, Complex *dst) {
	dst->imagin = src1->imagin - src2->imagin;
	dst->real = src1->real - src2->real;
}
static void Multy_Complex(Complex * src1, Complex *src2, Complex *dst) {
	float r1 = 0.0, r2 = 0.0;
	float i1 = 0.0, i2 = 0.0;
	r1 = src1->real;
	r2 = src2->real;
	i1 = src1->imagin;
	i2 = src2->imagin;
	dst->imagin = r1*i2 + r2*i1;
	dst->real = r1*r2 - i1*i2;
}
////////////////////////////////////////////////////////////////////
//?FFT????WN?n???,?????????,???????
///////////////////////////////////////////////////////////////////
static void getWN(float n, float size_n, Complex * dst) {
	float x = 2.0*M_PI*n / size_n;
	dst->imagin = -sin(x);
	dst->real = cos(x);
}

static int FFT_remap(float * src, int size_n) {

	if (size_n == 1)
		return 0;
	float * temp = (float *)malloc(sizeof(float)*size_n);
	int i = 0;
	for (i = 0; i<size_n; i++)
		if (i % 2 == 0)
			temp[i / 2] = src[i];
		else
			temp[(size_n + i) / 2] = src[i];
	i = 0;
	for (i = 0; i<size_n; i++)
		src[i] = temp[i];
	free(temp);
	FFT_remap(src, size_n / 2);
	FFT_remap(src + size_n / 2, size_n / 2);
	return 1;


}
////////////////////////////////////////////////////////////////////
//??FFT,???????,?????????????,??????
///////////////////////////////////////////////////////////////////

void FFT(float * src, Complex * dst, int size_n) {
	FFT_remap(src, size_n);
	
	int k = size_n;
	int z = 0;
	int i=0,j=0;
	while (k /= 2) {
		z++;
	}
	k = z;
	if (size_n != (1 << k))
		return ;
	Complex * src_com = (Complex*)malloc(sizeof(Complex)*size_n);
	if (src_com == 0)
		return;
	
	for (i = 0; i<size_n; i++) {
		src_com[i].real = src[i];
		src_com[i].imagin = 0;
	}
	for (i = 0; i<k; i++) {
		z = 0;
		
		for (j = 0; j<size_n; j++) {
			if ((j / (1 << i)) % 2 == 1) {
				Complex wn;
				getWN(z, size_n, &wn);
				Multy_Complex(&src_com[j], &wn, &src_com[j]);
				z += 1 << (k - i - 1);
				Complex temp;
				int neighbour = j - (1 << (i));
				temp.real = src_com[neighbour].real;
				temp.imagin = src_com[neighbour].imagin;
				Add_Complex(&temp, &src_com[j], &src_com[neighbour]);
				Sub_Complex(&temp, &src_com[j], &src_com[j]);
			}
			else
				z = 0;
		}

	}

	i = 0;
	for (i = 0; i<size_n; i++) {
		dst[i].imagin = src_com[i].imagin;
		dst[i].real = src_com[i].real;
	}
	
	free(src_com);
}
