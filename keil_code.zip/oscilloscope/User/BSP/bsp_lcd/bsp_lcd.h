#ifndef __LCD_H    //��ֹ�ظ�������ͷ�ļ������û�к궨��__LED_H�����#ifndef ��#else֮��Ĵ���Σ����û��#else�����#endif֮��Ĵ���Ρ�
#define	__LCD_H

#include "stm32f4xx.h"
#include "stdio.h "
#include "math.h"
#include "string.h"
#include "./English/English.h"

//lcd�ߴ磬����Ϊ��λ
#define  LCD_WIDTH       ((uint16_t)800)
#define  LCD_HEIGHT      ((uint16_t)480)


/*Layer1���Դ��ַ���õ���RGB565��ʽ��ÿ������2B*/
#define LCD_Layer1_BUFFER       ((uint32_t)0xD0000000)
/*Layer2���Դ��ַ���õ���RGB565��ʽ��ÿ������2B*/
#define LCD_Layer2_BUFFER        ((uint32_t)0xD0000000+800*480*2+200)

//ʱ����
#define HSW  2
#define HBP  46
#define HFP  210
#define VSW  2
#define VBP  23
#define VFP  22
/*
*���Ŷ���
*/
//R
#define LTDC_R0_PORT        GPIOH
#define LTDC_R0_PIN         GPIO_Pin_2
#define LTDC_R0_CLK         RCC_AHB1Periph_GPIOH
#define LTDC_R0_PINSOURCE   GPIO_PinSource2
#define LTDC_R0_AF          GPIO_AF_LTDC  

#define LTDC_R1_PORT        GPIOH
#define LTDC_R1_PIN         GPIO_Pin_3
#define LTDC_R1_CLK         RCC_AHB1Periph_GPIOH 
#define LTDC_R1_PINSOURCE   GPIO_PinSource3 
#define LTDC_R1_AF          GPIO_AF_LTDC

#define LTDC_R2_PORT        GPIOH
#define LTDC_R2_PIN         GPIO_Pin_8
#define LTDC_R2_CLK         RCC_AHB1Periph_GPIOH   
#define LTDC_R2_PINSOURCE   GPIO_PinSource8 
#define LTDC_R2_AF          GPIO_AF_LTDC

#define LTDC_R3_PORT        GPIOB
#define LTDC_R3_PIN         GPIO_Pin_0
#define LTDC_R3_CLK         RCC_AHB1Periph_GPIOB   
#define LTDC_R3_PINSOURCE   GPIO_PinSource0
#define LTDC_R3_AF          GPIO_AF9_LTDC

#define LTDC_R4_PORT        GPIOA
#define LTDC_R4_PIN         GPIO_Pin_11
#define LTDC_R4_CLK         RCC_AHB1Periph_GPIOA  
#define LTDC_R4_PINSOURCE   GPIO_PinSource11
#define LTDC_R4_AF          GPIO_AF_LTDC

#define LTDC_R5_PORT        GPIOA
#define LTDC_R5_PIN         GPIO_Pin_12
#define LTDC_R5_CLK         RCC_AHB1Periph_GPIOA 
#define LTDC_R5_PINSOURCE   GPIO_PinSource12
#define LTDC_R5_AF          GPIO_AF_LTDC

#define LTDC_R6_PORT        GPIOB
#define LTDC_R6_PIN         GPIO_Pin_1
#define LTDC_R6_CLK         RCC_AHB1Periph_GPIOB   
#define LTDC_R6_PINSOURCE   GPIO_PinSource1
#define LTDC_R6_AF          GPIO_AF9_LTDC

#define LTDC_R7_PORT        GPIOG
#define LTDC_R7_PIN         GPIO_Pin_6
#define LTDC_R7_CLK         RCC_AHB1Periph_GPIOG   
#define LTDC_R7_PINSOURCE   GPIO_PinSource6
#define LTDC_R7_AF          GPIO_AF_LTDC
//G
#define LTDC_G0_PORT        GPIOE
#define LTDC_G0_PIN         GPIO_Pin_5
#define LTDC_G0_CLK         RCC_AHB1Periph_GPIOE   
#define LTDC_G0_PINSOURCE   GPIO_PinSource5  
#define LTDC_G0_AF          GPIO_AF_LTDC

#define LTDC_G1_PORT        GPIOE
#define LTDC_G1_PIN         GPIO_Pin_6
#define LTDC_G1_CLK         RCC_AHB1Periph_GPIOE   
#define LTDC_G1_PINSOURCE   GPIO_PinSource6 
#define LTDC_G1_AF          GPIO_AF_LTDC

#define LTDC_G2_PORT        GPIOH
#define LTDC_G2_PIN         GPIO_Pin_13
#define LTDC_G2_CLK         RCC_AHB1Periph_GPIOH       
#define LTDC_G2_PINSOURCE   GPIO_PinSource3 
#define LTDC_G2_AF          GPIO_AF_LTDC

#define LTDC_G3_PORT        GPIOG
#define LTDC_G3_PIN         GPIO_Pin_10
#define LTDC_G3_CLK         RCC_AHB1Periph_GPIOG      
#define LTDC_G3_PINSOURCE   GPIO_PinSource10
#define LTDC_G3_AF          GPIO_AF9_LTDC

#define LTDC_G4_PORT        GPIOH
#define LTDC_G4_PIN         GPIO_Pin_15
#define LTDC_G4_CLK         RCC_AHB1Periph_GPIOH     
#define LTDC_G4_PINSOURCE   GPIO_PinSource15 
#define LTDC_G4_AF          GPIO_AF_LTDC

#define LTDC_G5_PORT        GPIOI
#define LTDC_G5_PIN         GPIO_Pin_0
#define LTDC_G5_CLK         RCC_AHB1Periph_GPIOI     
#define LTDC_G5_PINSOURCE   GPIO_PinSource0  
#define LTDC_G5_AF          GPIO_AF_LTDC

#define LTDC_G6_PORT        GPIOC
#define LTDC_G6_PIN         GPIO_Pin_7
#define LTDC_G6_CLK         RCC_AHB1Periph_GPIOC     
#define LTDC_G6_PINSOURCE   GPIO_PinSource7  
#define LTDC_G6_AF          GPIO_AF_LTDC

#define LTDC_G7_PORT        GPIOI
#define LTDC_G7_PIN         GPIO_Pin_2
#define LTDC_G7_CLK         RCC_AHB1Periph_GPIOI     
#define LTDC_G7_PINSOURCE   GPIO_PinSource2
#define LTDC_G7_AF          GPIO_AF_LTDC
//B
#define LTDC_B0_PORT        GPIOE
#define LTDC_B0_PIN         GPIO_Pin_4
#define LTDC_B0_CLK         RCC_AHB1Periph_GPIOE   
#define LTDC_B0_PINSOURCE   GPIO_PinSource4  
#define LTDC_B0_AF          GPIO_AF_LTDC

#define LTDC_B1_PORT        GPIOG
#define LTDC_B1_PIN         GPIO_Pin_12
#define LTDC_B1_CLK         RCC_AHB1Periph_GPIOG   
#define LTDC_B1_PINSOURCE   GPIO_PinSource12
#define LTDC_B1_AF          GPIO_AF_LTDC

#define LTDC_B2_PORT        GPIOD
#define LTDC_B2_PIN         GPIO_Pin_6
#define LTDC_B2_CLK         RCC_AHB1Periph_GPIOD       
#define LTDC_B2_PINSOURCE   GPIO_PinSource6 
#define LTDC_B2_AF          GPIO_AF_LTDC

#define LTDC_B3_PORT        GPIOG
#define LTDC_B3_PIN         GPIO_Pin_11
#define LTDC_B3_CLK         RCC_AHB1Periph_GPIOG       
#define LTDC_B3_PINSOURCE   GPIO_PinSource11  
#define LTDC_B3_AF          GPIO_AF_LTDC

#define LTDC_B4_PORT        GPIOI
#define LTDC_B4_PIN         GPIO_Pin_4
#define LTDC_B4_CLK         RCC_AHB1Periph_GPIOI     
#define LTDC_B4_PINSOURCE   GPIO_PinSource4
#define LTDC_B4_AF          GPIO_AF_LTDC

#define LTDC_B5_PORT        GPIOA
#define LTDC_B5_PIN         GPIO_Pin_3
#define LTDC_B5_CLK         RCC_AHB1Periph_GPIOA     
#define LTDC_B5_PINSOURCE   GPIO_PinSource3  
#define LTDC_B5_AF          GPIO_AF_LTDC

#define LTDC_B6_PORT        GPIOB
#define LTDC_B6_PIN         GPIO_Pin_8
#define LTDC_B6_CLK         RCC_AHB1Periph_GPIOB     
#define LTDC_B6_PINSOURCE   GPIO_PinSource8  
#define LTDC_B6_AF          GPIO_AF_LTDC

#define LTDC_B7_PORT        GPIOB
#define LTDC_B7_PIN         GPIO_Pin_9
#define LTDC_B7_CLK         RCC_AHB1Periph_GPIOB      
#define LTDC_B7_PINSOURCE   GPIO_PinSource9  
#define LTDC_B7_AF          GPIO_AF_LTDC
//������
//HSY ˮƽ���У�ͬ��
#define LTDC_HSY_PORT        GPIOI
#define LTDC_HSY_PIN         GPIO_Pin_10
#define LTDC_HSY_CLK         RCC_AHB1Periph_GPIOI    
#define LTDC_HSY_PINSOURCE   GPIO_PinSource10 
#define LTDC_HSY_AF          GPIO_AF_LTDC
//VSY ��ֱ��֡��ͬ��
#define LTDC_VSY_PORT        GPIOI
#define LTDC_VSY_PIN         GPIO_Pin_9
#define LTDC_VSY_CLK         RCC_AHB1Periph_GPIOI   
#define LTDC_VSY_PINSOURCE   GPIO_PinSource9
#define LTDC_VSY_AF          GPIO_AF_LTDC
//DE ����ʹ��
#define LTDC_DE_PORT        GPIOF
#define LTDC_DE_PIN         GPIO_Pin_10
#define LTDC_DE_CLK         RCC_AHB1Periph_GPIOF  
#define LTDC_DE_PINSOURCE   GPIO_PinSource10
#define LTDC_DE_AF          GPIO_AF_LTDC
//CLK
#define LTDC_CLK_PORT        GPIOG
#define LTDC_CLK_PIN         GPIO_Pin_7
#define LTDC_CKL_CLK         RCC_AHB1Periph_GPIOG   
#define LTDC_CLK_PINSOURCE   GPIO_PinSource7
#define LTDC_CLK_AF          GPIO_AF_LTDC
/*����Ϊ��ͨI/O*/
//DISP��Һ����ʹ��
#define LTDC_DISP_PORT       GPIOD 
#define LTDC_DISP_PIN        GPIO_Pin_4
#define LTDC_DISP_CLK        RCC_AHB1Periph_GPIOD   
//BL,����
#define LTDC_BL_PORT       GPIOD 
#define LTDC_BL_PIN        GPIO_Pin_7
#define LTDC_BL_CLK        RCC_AHB1Periph_GPIOD   
/*
*��������
*/
void bsp_LCD_Init(void);
void LCD_Layer1Init(void);
void LCD_Layer2Init(void);
void PutPixel2(int16_t x, int16_t y,uint16_t CurrentTextColor);//дһ������
void PutPixel1(int16_t x, int16_t y,uint16_t CurrentTextColor);
uint16_t ReadPixel2(int16_t x, int16_t y);//��һ������
uint16_t ReadPixel1(int16_t x, int16_t y);
void dma2d_Layer2_display(uint16_t color,uint16_t width ,uint16_t highly,uint32_t start);//dma2d������
void rect_Layer2_display(uint16_t color,uint16_t width ,uint16_t highly,uint16_t x,uint16_t y);//������
void LCD_DrawUniLineCircle(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2,uint16_t color);//������֮�����켣
void LCD_DrawCircle(uint16_t Xpos, uint16_t Ypos, uint16_t Radius,uint16_t color);//������Բ
void LCD_DrawEllipse(int Xpos, int Ypos, int Radius, int Radius2,uint16_t color);//����Բ
void LCD_DrawFullEllipse(int Xpos, int Ypos, int Radius, int Radius2,uint16_t color);//��仭��Բ
void LCD_DrawFullCircle(uint16_t Xpos, uint16_t Ypos, uint16_t Radius,uint16_t color);//�����Բ
void LCD_DrawRect(uint16_t Xpos, uint16_t Ypos, uint16_t Height, uint16_t Width,uint16_t color);

void display_Init(void);
void display_DisInit(void);
void dis_charater(uint16_t x, uint16_t y, uint16_t charater) ;
void dis_Echarater(uint16_t x, uint16_t y, uint8_t charater); 
void dis_string(uint16_t x, uint16_t y,char *pString);
void dis_digital(uint16_t x, uint16_t y,int num,int radix);
void my_ftoa(uint16_t x, uint16_t y,double number,int ndigit);  
void SetFontColors(uint16_t Color);
void SetFontbackColors(uint16_t Color);

#endif
